#include "app.h"

extern BYTE I2C_NIXIE_write(BYTE p_unit_no, BYTE p_write_address, BYTE *p_write_data, BYTE p_date_len);
extern BYTE I2C_NIXIE_read(BYTE p_unit_no, BYTE p_read_address, BYTE *p_read_data, BYTE p_data_len);

