//	EEPROM�ǂݏ������C�u����
//		2010/08/11	����
#include <p18f14k50.h>
#include <EEP.h>
#include "eeprom.h"

unsigned char ReadEEPROM(int adr)
{
//	return Read_b_eep( adr );
#if 1
	EEADR = adr;
	EECON1 = 0x00;
	EECON1bits.RD = 1;
//	NOP();
	EEADR = 0xFF;
	return(EEDATA);
#endif
}

void WriteEEPROM(int adr,unsigned char data)
{
//	Write_b_eep(adr, data);
#if 1
	EEADR = adr;
	EEDATA = data;
	EECON1 = 0x04;
	EECON2 = 0x55;
	EECON2 = 0xAA;
	EECON1bits.WR = 1;
	while(EECON1bits.WR);
	EEADR = 0xFF;
#endif
}

unsigned char ReadEEPROM_Agree(int adr, unsigned char read_count, unsigned char agree_num, unsigned char *val)
{
	unsigned char uc_ret = 1;	// NG
	unsigned char count = 0;
	unsigned char fi, fj;
	unsigned char fi_val;
	*val = 0;
	
	for( fi = 0; fi < read_count; fi++ )
	{
		count = 0;
		fi_val = ReadEEPROM(adr + fi);
		for( fj = fi+1; fj < read_count; fj++)
		{
			if(fi_val == ReadEEPROM(adr + fj))
			{
				count++;
			}	
		}	
		if(count >= (agree_num - 1))
		{
			// OK
			*val = fi_val;
			uc_ret = 0;
			break;
		}
	}
	
	return uc_ret;
}	

void WriteEEPROM_Agree(int adr, unsigned char data, unsigned char write_count)
{
	unsigned char fi;
	for( fi = 0; fi < write_count; fi++ )
	{
		WriteEEPROM(adr + fi, data);
	}
}