//	EEPROM�ǂݏ������C�u����
//		2010/08/11	����

unsigned char ReadEEPROM(int adr);
void WriteEEPROM(int adr,unsigned char data);
unsigned char ReadEEPROM_Agree(int adr, unsigned char read_count, unsigned char agree_num, unsigned char *val);
void WriteEEPROM_Agree(int adr, unsigned char data, unsigned char write_count);
