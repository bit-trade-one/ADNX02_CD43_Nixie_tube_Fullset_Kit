﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Microsoft.Win32.SafeHandles;
using NIXIE_CTRL_Library;

namespace NIXIE_CTRL_sample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_send1_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;

            try
            {
                // USB DEVICEオープン
                handle_usb_device = NIXIE_CTRL.openNixieCtrl(this.Handle);
                if (handle_usb_device != null)
                {

                    // リアルタイムクロック設定
                    // システム時刻を設定する
                    DateTime dt = DateTime.Now;
                    i_ret = NIXIE_CTRL.setRTCDateTime(handle_usb_device, dt.Year, dt.Month, dt.Day, (int)dt.DayOfWeek, dt.Hour, dt.Minute, dt.Second);

                    // 2013/04/26 13:15:30
                    //i_ret = NIXIE_CTRL.setRTCDateTime(handle_usb_device, 2013, 04, 26, 0, 13, 15, 30);
                }

            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = NIXIE_CTRL.closeNixieCtrl(handle_usb_device);
                }
            }
        }

        private void btn_send2_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            NIXIE_CTRL.NIXIE_DATE_FORMAT[] date_format = new NIXIE_CTRL.NIXIE_DATE_FORMAT[4];
            byte[] ctrl1 = new byte[4];
            int i_ret = 0;

            try
            {
                // USB DEVICEオープン
                handle_usb_device = NIXIE_CTRL.openNixieCtrl(this.Handle);
                if (handle_usb_device != null)
                {
                    // 設定ユニットNo
                    byte unit_no = 1;   // ユニット１指定
                    // 日時表示データの指定
                    date_format[0] = NIXIE_CTRL.NIXIE_DATE_FORMAT.YEAR_Xxxx;    // ニキシー管１に年の千の桁表示指定
                    date_format[1] = NIXIE_CTRL.NIXIE_DATE_FORMAT.YEAR_xXxx;    // ニキシー管２に年の百の桁表示指定
                    date_format[2] = NIXIE_CTRL.NIXIE_DATE_FORMAT.YEAR_xxXx;    // ニキシー管３に年の十の桁表示指定
                    date_format[3] = NIXIE_CTRL.NIXIE_DATE_FORMAT.YEAR_xxxX;    // ニキシー管４に年の一の桁表示指定

                    ctrl1[0] = 0x01;    // ニキシー管１　右ドット点灯指定
                    ctrl1[1] = 0x02;    // ニキシー管２　左ドット点灯指定
                    ctrl1[2] = 0x04;    // ニキシー管３　右ドット点滅指定
                    ctrl1[3] = 0x08;    // ニキシー管４　左ドット点滅指定

                    // 標準設定の日時表示設定
                    i_ret = NIXIE_CTRL.setDateFormat(handle_usb_device, unit_no, date_format, ctrl1, 4);
                }

            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = NIXIE_CTRL.closeNixieCtrl(handle_usb_device);
                }
            }
        }

        private void btn_send3_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            byte[] number = new byte[4];
            byte[] ctrl1 = new byte[4];
            int i_ret = 0;

            try
            {
                // USB DEVICEオープン
                handle_usb_device = NIXIE_CTRL.openNixieCtrl(this.Handle);
                if (handle_usb_device != null)
                {
                    // 設定ユニットNo
                    byte unit_no = 1;   // ユニット１指定
                    // 数字表示データの指定
                    number[0] = 1;    // ニキシー管１の表示数字指定
                    number[1] = 2;    // ニキシー管２の表示数字指定
                    number[2] = 3;    // ニキシー管３の表示数字指定
                    number[3] = 4;    // ニキシー管４の表示数字指定

                    ctrl1[0] = 0x01;    // ニキシー管１　右ドット点灯指定
                    ctrl1[1] = 0x02;    // ニキシー管２　左ドット点灯指定
                    ctrl1[2] = 0x04;    // ニキシー管３　右ドット点滅指定
                    ctrl1[3] = 0x08;    // ニキシー管４　左ドット点滅指定

                    // 表示データ設定　ユニット指定
                    i_ret = NIXIE_CTRL.setNumber(handle_usb_device, unit_no, number, ctrl1, 4);
                }

            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = NIXIE_CTRL.closeNixieCtrl(handle_usb_device);
                }
            }
        }

        private void btn_send4_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            byte[] number = new byte[4];
            byte[] ctrl1 = new byte[4];
            int i_ret = 0;

            try
            {
                // USB DEVICEオープン
                handle_usb_device = NIXIE_CTRL.openNixieCtrl(this.Handle);
                if (handle_usb_device != null)
                {
                    // 設定ユニットNo
                    byte unit_no = 1;   // ユニット１指定
                    // 数字表示データの指定
                    number[0] = 5;      // ニキシー管１の表示数字指定
                    number[1] = 0xFF;   // ニキシー管２の表示数字指定 非表示指定
                    number[2] = 0xFF;   // ニキシー管３の表示数字指定 非表示指定
                    number[3] = 8;      // ニキシー管４の表示数字指定

                    ctrl1[0] = 0x10;    // ニキシー管１　フェード指定
                    ctrl1[1] = 0x00;    // ニキシー管２　指定無し
                    ctrl1[2] = 0x00;    // ニキシー管３　指定無し
                    ctrl1[3] = 0x20;    // ニキシー管４　数字点滅指定

                    // 表示データ設定　ユニット指定
                    i_ret = NIXIE_CTRL.setNumber(handle_usb_device, unit_no, number, ctrl1, 4);
                }

            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = NIXIE_CTRL.closeNixieCtrl(handle_usb_device);
                }
            }
        }

        private void btn_send5_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            byte[,] number = new byte[4,4];
            byte[,] ctrl1 = new byte[4,4];
            int i_ret = 0;

            try
            {
                // USB DEVICEオープン
                handle_usb_device = NIXIE_CTRL.openNixieCtrl(this.Handle);
                if (handle_usb_device != null)
                {
                    //　ニキシー管ユニット１
                    // 数字表示データの指定
                    number[0, 0] = 1;        // ニキシー管１の表示数字指定
                    number[0, 1] = 2;        // ニキシー管２の表示数字指定
                    number[0, 2] = 3;        // ニキシー管３の表示数字指定
                    number[0, 3] = 4;        // ニキシー管４の表示数字指定

                    ctrl1[0, 0] = 0x00;      // ニキシー管１　指定無し
                    ctrl1[0, 1] = 0x00;      // ニキシー管２　指定無し
                    ctrl1[0, 2] = 0x01;      // ニキシー管３　右ドット点灯指定
                    ctrl1[0, 3] = 0x02;      // ニキシー管４　左ドット点灯指定

                    //　ニキシー管ユニット２
                    // 数字表示データの指定
                    number[1, 0] = 2;        // ニキシー管１の表示数字指定
                    number[1, 1] = 3;        // ニキシー管２の表示数字指定
                    number[1, 2] = 4;        // ニキシー管３の表示数字指定
                    number[1, 3] = 5;        // ニキシー管４の表示数字指定

                    ctrl1[1, 0] = 0x04;      // ニキシー管１　右ドット点滅指定し
                    ctrl1[1, 1] = 0x08;      // ニキシー管２　左ドット点滅指定
                    ctrl1[1, 2] = 0x00;      // ニキシー管３　指定無し
                    ctrl1[1, 3] = 0x00;      // ニキシー管４　指定無し


                    //　ニキシー管ユニット３
                    // 数字表示データの指定
                    number[2, 0] = 3;        // ニキシー管１の表示数字指定
                    number[2, 1] = 4;        // ニキシー管２の表示数字指定
                    number[2, 2] = 5;        // ニキシー管３の表示数字指定
                    number[2, 3] = 6;        // ニキシー管４の表示数字指定

                    ctrl1[2, 0] = 0x00;      // ニキシー管１　指定無し
                    ctrl1[2, 1] = 0x20;      // ニキシー管２　数字点滅指定
                    ctrl1[2, 2] = 0x20;      // ニキシー管３　数字点滅指定
                    ctrl1[2, 3] = 0x00;      // ニキシー管４　指定無し

                    //　ニキシー管ユニット４
                    // 数字表示データの指定
                    number[3, 0] = 4;        // ニキシー管１の表示数字指定
                    number[3, 1] = 5;        // ニキシー管２の表示数字指定
                    number[3, 2] = 6;        // ニキシー管３の表示数字指定
                    number[3, 3] = 7;        // ニキシー管４の表示数字指定

                    ctrl1[3, 0] = 0x10;      // ニキシー管１　フェード指定
                    ctrl1[3, 1] = 0x00;      // ニキシー管２　指定無し
                    ctrl1[3, 2] = 0x00;      // ニキシー管３　指定無し
                    ctrl1[3, 3] = 0x10;      // ニキシー管４　フェード指定

                    // 表示データ一括設定
                    i_ret = NIXIE_CTRL.setNumberFast(handle_usb_device, number, ctrl1, 4, 4);
                }

            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = NIXIE_CTRL.closeNixieCtrl(handle_usb_device);
                }
            }
        }
    }
}
