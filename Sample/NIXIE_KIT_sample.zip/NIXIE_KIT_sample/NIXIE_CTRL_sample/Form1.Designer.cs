﻿namespace NIXIE_CTRL_sample
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_send1 = new System.Windows.Forms.Button();
            this.btn_send2 = new System.Windows.Forms.Button();
            this.btn_send3 = new System.Windows.Forms.Button();
            this.btn_send4 = new System.Windows.Forms.Button();
            this.btn_send5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_send1
            // 
            this.btn_send1.Location = new System.Drawing.Point(33, 20);
            this.btn_send1.Name = "btn_send1";
            this.btn_send1.Size = new System.Drawing.Size(200, 23);
            this.btn_send1.TabIndex = 0;
            this.btn_send1.Text = "日時設定";
            this.btn_send1.UseVisualStyleBackColor = true;
            this.btn_send1.Click += new System.EventHandler(this.btn_send1_Click);
            // 
            // btn_send2
            // 
            this.btn_send2.Location = new System.Drawing.Point(33, 60);
            this.btn_send2.Name = "btn_send2";
            this.btn_send2.Size = new System.Drawing.Size(200, 23);
            this.btn_send2.TabIndex = 1;
            this.btn_send2.Text = "標準設定の日時表示設定";
            this.btn_send2.UseVisualStyleBackColor = true;
            this.btn_send2.Click += new System.EventHandler(this.btn_send2_Click);
            // 
            // btn_send3
            // 
            this.btn_send3.Location = new System.Drawing.Point(33, 100);
            this.btn_send3.Name = "btn_send3";
            this.btn_send3.Size = new System.Drawing.Size(200, 23);
            this.btn_send3.TabIndex = 2;
            this.btn_send3.Text = "カスタム設定１";
            this.btn_send3.UseVisualStyleBackColor = true;
            this.btn_send3.Click += new System.EventHandler(this.btn_send3_Click);
            // 
            // btn_send4
            // 
            this.btn_send4.Location = new System.Drawing.Point(33, 140);
            this.btn_send4.Name = "btn_send4";
            this.btn_send4.Size = new System.Drawing.Size(200, 23);
            this.btn_send4.TabIndex = 3;
            this.btn_send4.Text = "カスタム設定２";
            this.btn_send4.UseVisualStyleBackColor = true;
            this.btn_send4.Click += new System.EventHandler(this.btn_send4_Click);
            // 
            // btn_send5
            // 
            this.btn_send5.Location = new System.Drawing.Point(33, 181);
            this.btn_send5.Name = "btn_send5";
            this.btn_send5.Size = new System.Drawing.Size(200, 23);
            this.btn_send5.TabIndex = 4;
            this.btn_send5.Text = "全ユニット一括設定";
            this.btn_send5.UseVisualStyleBackColor = true;
            this.btn_send5.Click += new System.EventHandler(this.btn_send5_Click);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(492, 225);
            this.Controls.Add(this.btn_send5);
            this.Controls.Add(this.btn_send4);
            this.Controls.Add(this.btn_send3);
            this.Controls.Add(this.btn_send2);
            this.Controls.Add(this.btn_send1);
            this.Name = "Form1";
            this.Text = "ニキシー管キット　ライブラリ使用方法サンプル";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_send1;
        private System.Windows.Forms.Button btn_send2;
        private System.Windows.Forms.Button btn_send3;
        private System.Windows.Forms.Button btn_send4;
        private System.Windows.Forms.Button btn_send5;
    }
}

