namespace NixieKit
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ReadWriteThread = new System.ComponentModel.BackgroundWorker();
            this.FormUpdateTimer = new System.Windows.Forms.Timer(this.components);
            this.connect_status_lbl = new System.Windows.Forms.Label();
            this.debug01_lbl = new System.Windows.Forms.Label();
            this.debug02_lbl = new System.Windows.Forms.Label();
            this.debug03_lbl = new System.Windows.Forms.Label();
            this.colum_lbl = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.lbl_FW_Version = new System.Windows.Forms.Label();
            this.txtbox_Num1 = new System.Windows.Forms.TextBox();
            this.txtbox_Num2 = new System.Windows.Forms.TextBox();
            this.txtbox_Num3 = new System.Windows.Forms.TextBox();
            this.txtbox_Num4 = new System.Windows.Forms.TextBox();
            this.cmbbox_Unit = new System.Windows.Forms.ComboBox();
            this.btn_Set_Number = new System.Windows.Forms.Button();
            this.btn_Set_Number_All = new System.Windows.Forms.Button();
            this.btn_Read_Number = new System.Windows.Forms.Button();
            this.dgv_DispSetData = new System.Windows.Forms.DataGridView();
            this.time = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit1_1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit1_2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit1_3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit1_4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit2_1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit2_2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit2_3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit2_4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit3_1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit3_2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit3_3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit3_4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit4_1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit4_2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit4_3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit4_4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbx_unit1 = new System.Windows.Forms.GroupBox();
            this.cmbbx_standard_unit1 = new System.Windows.Forms.ComboBox();
            this.rbtn_custom_unit1 = new System.Windows.Forms.RadioButton();
            this.rbtn_standard_unit1 = new System.Windows.Forms.RadioButton();
            this.gbx_unit2 = new System.Windows.Forms.GroupBox();
            this.cmbbx_standard_unit2 = new System.Windows.Forms.ComboBox();
            this.rbtn_custom_unit2 = new System.Windows.Forms.RadioButton();
            this.rbtn_standard_unit2 = new System.Windows.Forms.RadioButton();
            this.gbx_unit3 = new System.Windows.Forms.GroupBox();
            this.cmbbx_standard_unit3 = new System.Windows.Forms.ComboBox();
            this.rbtn_custom_unit3 = new System.Windows.Forms.RadioButton();
            this.rbtn_standard_unit3 = new System.Windows.Forms.RadioButton();
            this.gbx_unit4 = new System.Windows.Forms.GroupBox();
            this.cmbbx_standard_unit4 = new System.Windows.Forms.ComboBox();
            this.rbtn_custom_unit4 = new System.Windows.Forms.RadioButton();
            this.rbtn_standard_unit4 = new System.Windows.Forms.RadioButton();
            this.btn_Set = new System.Windows.Forms.Button();
            this.btn_Import = new System.Windows.Forms.Button();
            this.btn_Export = new System.Windows.Forms.Button();
            this.gbx_loop = new System.Windows.Forms.GroupBox();
            this.rbtn_loop = new System.Windows.Forms.RadioButton();
            this.rbtn_one = new System.Windows.Forms.RadioButton();
            this.gbx_Custom_Setting = new System.Windows.Forms.GroupBox();
            this.picbx_Custom4 = new System.Windows.Forms.PictureBox();
            this.picbx_Custom3 = new System.Windows.Forms.PictureBox();
            this.picbx_Custom2 = new System.Windows.Forms.PictureBox();
            this.picbx_Custom1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.StatusBox_lbl2 = new System.Windows.Forms.Label();
            this.StatusBox_lbl = new System.Windows.Forms.Label();
            this.Status_NC_pb = new System.Windows.Forms.PictureBox();
            this.Status_C_pb = new System.Windows.Forms.PictureBox();
            this.lbl_Set_Date = new System.Windows.Forms.Label();
            this.imageList_Set_Date = new System.Windows.Forms.ImageList(this.components);
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_DispSetData)).BeginInit();
            this.gbx_unit1.SuspendLayout();
            this.gbx_unit2.SuspendLayout();
            this.gbx_unit3.SuspendLayout();
            this.gbx_unit4.SuspendLayout();
            this.gbx_loop.SuspendLayout();
            this.gbx_Custom_Setting.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Custom4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Custom3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Custom2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Custom1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_NC_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_C_pb)).BeginInit();
            this.SuspendLayout();
            // 
            // ReadWriteThread
            // 
            this.ReadWriteThread.WorkerReportsProgress = true;
            this.ReadWriteThread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.ReadWriteThread_DoWork);
            // 
            // FormUpdateTimer
            // 
            this.FormUpdateTimer.Enabled = true;
            this.FormUpdateTimer.Interval = 10;
            this.FormUpdateTimer.Tick += new System.EventHandler(this.FormUpdateTimer_Tick);
            // 
            // connect_status_lbl
            // 
            this.connect_status_lbl.AutoSize = true;
            this.connect_status_lbl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.connect_status_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(27)))), ((int)(((byte)(26)))));
            this.connect_status_lbl.Location = new System.Drawing.Point(810, 694);
            this.connect_status_lbl.Name = "connect_status_lbl";
            this.connect_status_lbl.Size = new System.Drawing.Size(41, 12);
            this.connect_status_lbl.TabIndex = 26;
            this.connect_status_lbl.Text = "���ڑ�";
            // 
            // debug01_lbl
            // 
            this.debug01_lbl.Font = new System.Drawing.Font("�l�r �S�V�b�N", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.debug01_lbl.Location = new System.Drawing.Point(6, 48);
            this.debug01_lbl.Name = "debug01_lbl";
            this.debug01_lbl.Size = new System.Drawing.Size(776, 24);
            this.debug01_lbl.TabIndex = 27;
            this.debug01_lbl.Text = "label1";
            // 
            // debug02_lbl
            // 
            this.debug02_lbl.Font = new System.Drawing.Font("�l�r �S�V�b�N", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.debug02_lbl.Location = new System.Drawing.Point(6, 81);
            this.debug02_lbl.Name = "debug02_lbl";
            this.debug02_lbl.Size = new System.Drawing.Size(776, 24);
            this.debug02_lbl.TabIndex = 28;
            this.debug02_lbl.Text = "label1";
            // 
            // debug03_lbl
            // 
            this.debug03_lbl.Font = new System.Drawing.Font("�l�r �S�V�b�N", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.debug03_lbl.Location = new System.Drawing.Point(6, 117);
            this.debug03_lbl.Name = "debug03_lbl";
            this.debug03_lbl.Size = new System.Drawing.Size(776, 24);
            this.debug03_lbl.TabIndex = 29;
            this.debug03_lbl.Text = "label1";
            // 
            // colum_lbl
            // 
            this.colum_lbl.Font = new System.Drawing.Font("�l�r �S�V�b�N", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.colum_lbl.Location = new System.Drawing.Point(6, 15);
            this.colum_lbl.Name = "colum_lbl";
            this.colum_lbl.Size = new System.Drawing.Size(776, 24);
            this.colum_lbl.TabIndex = 31;
            this.colum_lbl.Text = "label1";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "CSV�t�@�C��(*.csv)|*.csv|���ׂẴt�@�C��(*.*)|*.*";
            this.openFileDialog1.Title = "�J���t�@�C����I�����Ă�������";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.colum_lbl);
            this.groupBox1.Controls.Add(this.debug01_lbl);
            this.groupBox1.Controls.Add(this.debug02_lbl);
            this.groupBox1.Controls.Add(this.debug03_lbl);
            this.groupBox1.Location = new System.Drawing.Point(8, 550);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(792, 156);
            this.groupBox1.TabIndex = 64;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "csv";
            this.saveFileDialog1.Filter = "CSV(�J���}��؂�)(*.csv)|*.csv";
            this.saveFileDialog1.Title = "���O��t���ĕۑ�";
            // 
            // lbl_FW_Version
            // 
            this.lbl_FW_Version.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.lbl_FW_Version.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.lbl_FW_Version.Location = new System.Drawing.Point(756, 530);
            this.lbl_FW_Version.Name = "lbl_FW_Version";
            this.lbl_FW_Version.Size = new System.Drawing.Size(126, 12);
            this.lbl_FW_Version.TabIndex = 67;
            this.lbl_FW_Version.Text = "FW Version";
            // 
            // txtbox_Num1
            // 
            this.txtbox_Num1.Location = new System.Drawing.Point(806, 576);
            this.txtbox_Num1.MaxLength = 5;
            this.txtbox_Num1.Name = "txtbox_Num1";
            this.txtbox_Num1.Size = new System.Drawing.Size(45, 19);
            this.txtbox_Num1.TabIndex = 69;
            // 
            // txtbox_Num2
            // 
            this.txtbox_Num2.Location = new System.Drawing.Point(854, 576);
            this.txtbox_Num2.MaxLength = 5;
            this.txtbox_Num2.Name = "txtbox_Num2";
            this.txtbox_Num2.Size = new System.Drawing.Size(45, 19);
            this.txtbox_Num2.TabIndex = 70;
            // 
            // txtbox_Num3
            // 
            this.txtbox_Num3.Location = new System.Drawing.Point(902, 576);
            this.txtbox_Num3.MaxLength = 5;
            this.txtbox_Num3.Name = "txtbox_Num3";
            this.txtbox_Num3.Size = new System.Drawing.Size(45, 19);
            this.txtbox_Num3.TabIndex = 71;
            // 
            // txtbox_Num4
            // 
            this.txtbox_Num4.Location = new System.Drawing.Point(950, 576);
            this.txtbox_Num4.MaxLength = 5;
            this.txtbox_Num4.Name = "txtbox_Num4";
            this.txtbox_Num4.Size = new System.Drawing.Size(45, 19);
            this.txtbox_Num4.TabIndex = 72;
            // 
            // cmbbox_Unit
            // 
            this.cmbbox_Unit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbbox_Unit.FormattingEnabled = true;
            this.cmbbox_Unit.Items.AddRange(new object[] {
            "Unit 1",
            "Unit 2",
            "Unit 3",
            "Unit 4"});
            this.cmbbox_Unit.Location = new System.Drawing.Point(806, 550);
            this.cmbbox_Unit.Name = "cmbbox_Unit";
            this.cmbbox_Unit.Size = new System.Drawing.Size(76, 20);
            this.cmbbox_Unit.TabIndex = 73;
            // 
            // btn_Set_Number
            // 
            this.btn_Set_Number.Location = new System.Drawing.Point(806, 598);
            this.btn_Set_Number.Name = "btn_Set_Number";
            this.btn_Set_Number.Size = new System.Drawing.Size(54, 23);
            this.btn_Set_Number.TabIndex = 74;
            this.btn_Set_Number.Text = "�ݒ�";
            this.btn_Set_Number.UseVisualStyleBackColor = true;
            this.btn_Set_Number.Click += new System.EventHandler(this.btn_Set_Number_Click);
            // 
            // btn_Set_Number_All
            // 
            this.btn_Set_Number_All.Location = new System.Drawing.Point(861, 598);
            this.btn_Set_Number_All.Name = "btn_Set_Number_All";
            this.btn_Set_Number_All.Size = new System.Drawing.Size(60, 23);
            this.btn_Set_Number_All.TabIndex = 75;
            this.btn_Set_Number_All.Text = "�S�ݒ�";
            this.btn_Set_Number_All.UseVisualStyleBackColor = true;
            this.btn_Set_Number_All.Click += new System.EventHandler(this.btn_Set_Number_All_Click);
            // 
            // btn_Read_Number
            // 
            this.btn_Read_Number.Location = new System.Drawing.Point(922, 598);
            this.btn_Read_Number.Name = "btn_Read_Number";
            this.btn_Read_Number.Size = new System.Drawing.Size(75, 23);
            this.btn_Read_Number.TabIndex = 76;
            this.btn_Read_Number.Text = "�ǂݍ���";
            this.btn_Read_Number.UseVisualStyleBackColor = true;
            this.btn_Read_Number.Click += new System.EventHandler(this.btn_Read_Number_Click);
            // 
            // dgv_DispSetData
            // 
            this.dgv_DispSetData.AllowDrop = true;
            this.dgv_DispSetData.AllowUserToResizeColumns = false;
            this.dgv_DispSetData.AllowUserToResizeRows = false;
            this.dgv_DispSetData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_DispSetData.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.time,
            this.unit1_1,
            this.unit1_2,
            this.unit1_3,
            this.unit1_4,
            this.unit2_1,
            this.unit2_2,
            this.unit2_3,
            this.unit2_4,
            this.unit3_1,
            this.unit3_2,
            this.unit3_3,
            this.unit3_4,
            this.unit4_1,
            this.unit4_2,
            this.unit4_3,
            this.unit4_4});
            this.dgv_DispSetData.Location = new System.Drawing.Point(15, 41);
            this.dgv_DispSetData.Name = "dgv_DispSetData";
            this.dgv_DispSetData.RowTemplate.Height = 21;
            this.dgv_DispSetData.Size = new System.Drawing.Size(968, 181);
            this.dgv_DispSetData.TabIndex = 77;
            this.dgv_DispSetData.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dgv_DispSetData_MouseDown);
            this.dgv_DispSetData.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dgv_DispSetData_MouseMove);
            this.dgv_DispSetData.DragOver += new System.Windows.Forms.DragEventHandler(this.dgv_DispSetData_DragOver);
            this.dgv_DispSetData.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgv_DispSetData_KeyUp);
            this.dgv_DispSetData.DragDrop += new System.Windows.Forms.DragEventHandler(this.dgv_DispSetData_DragDrop);
            // 
            // time
            // 
            this.time.HeaderText = "����[*100ms]";
            this.time.MaxInputLength = 5;
            this.time.Name = "time";
            this.time.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.time.Width = 60;
            // 
            // unit1_1
            // 
            this.unit1_1.HeaderText = "NX1-1";
            this.unit1_1.MaxInputLength = 5;
            this.unit1_1.Name = "unit1_1";
            this.unit1_1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.unit1_1.Width = 53;
            // 
            // unit1_2
            // 
            this.unit1_2.HeaderText = "NX1-2";
            this.unit1_2.MaxInputLength = 5;
            this.unit1_2.Name = "unit1_2";
            this.unit1_2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.unit1_2.Width = 53;
            // 
            // unit1_3
            // 
            this.unit1_3.HeaderText = "NX1-3";
            this.unit1_3.MaxInputLength = 5;
            this.unit1_3.Name = "unit1_3";
            this.unit1_3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.unit1_3.Width = 53;
            // 
            // unit1_4
            // 
            this.unit1_4.HeaderText = "NX1-4";
            this.unit1_4.MaxInputLength = 5;
            this.unit1_4.Name = "unit1_4";
            this.unit1_4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.unit1_4.Width = 53;
            // 
            // unit2_1
            // 
            this.unit2_1.HeaderText = "NX2-1";
            this.unit2_1.MaxInputLength = 5;
            this.unit2_1.Name = "unit2_1";
            this.unit2_1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.unit2_1.Width = 53;
            // 
            // unit2_2
            // 
            this.unit2_2.HeaderText = "NX2-2";
            this.unit2_2.MaxInputLength = 5;
            this.unit2_2.Name = "unit2_2";
            this.unit2_2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.unit2_2.Width = 53;
            // 
            // unit2_3
            // 
            this.unit2_3.HeaderText = "NX2-3";
            this.unit2_3.MaxInputLength = 5;
            this.unit2_3.Name = "unit2_3";
            this.unit2_3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.unit2_3.Width = 53;
            // 
            // unit2_4
            // 
            this.unit2_4.HeaderText = "NX2-4";
            this.unit2_4.MaxInputLength = 5;
            this.unit2_4.Name = "unit2_4";
            this.unit2_4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.unit2_4.Width = 53;
            // 
            // unit3_1
            // 
            this.unit3_1.HeaderText = "NX3-1";
            this.unit3_1.MaxInputLength = 5;
            this.unit3_1.Name = "unit3_1";
            this.unit3_1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.unit3_1.Width = 53;
            // 
            // unit3_2
            // 
            this.unit3_2.HeaderText = "NX3-2";
            this.unit3_2.MaxInputLength = 5;
            this.unit3_2.Name = "unit3_2";
            this.unit3_2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.unit3_2.Width = 53;
            // 
            // unit3_3
            // 
            this.unit3_3.HeaderText = "NX3-3";
            this.unit3_3.MaxInputLength = 5;
            this.unit3_3.Name = "unit3_3";
            this.unit3_3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.unit3_3.Width = 53;
            // 
            // unit3_4
            // 
            this.unit3_4.HeaderText = "NX3-4";
            this.unit3_4.MaxInputLength = 5;
            this.unit3_4.Name = "unit3_4";
            this.unit3_4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.unit3_4.Width = 53;
            // 
            // unit4_1
            // 
            this.unit4_1.HeaderText = "NX4-1";
            this.unit4_1.MaxInputLength = 5;
            this.unit4_1.Name = "unit4_1";
            this.unit4_1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.unit4_1.Width = 53;
            // 
            // unit4_2
            // 
            this.unit4_2.HeaderText = "NX4-2";
            this.unit4_2.MaxInputLength = 5;
            this.unit4_2.Name = "unit4_2";
            this.unit4_2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.unit4_2.Width = 53;
            // 
            // unit4_3
            // 
            this.unit4_3.HeaderText = "NX4-3";
            this.unit4_3.MaxInputLength = 5;
            this.unit4_3.Name = "unit4_3";
            this.unit4_3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.unit4_3.Width = 53;
            // 
            // unit4_4
            // 
            this.unit4_4.HeaderText = "NX4-4";
            this.unit4_4.MaxInputLength = 5;
            this.unit4_4.Name = "unit4_4";
            this.unit4_4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.unit4_4.Width = 53;
            // 
            // gbx_unit1
            // 
            this.gbx_unit1.Controls.Add(this.cmbbx_standard_unit1);
            this.gbx_unit1.Controls.Add(this.rbtn_custom_unit1);
            this.gbx_unit1.Controls.Add(this.rbtn_standard_unit1);
            this.gbx_unit1.Location = new System.Drawing.Point(103, 12);
            this.gbx_unit1.Name = "gbx_unit1";
            this.gbx_unit1.Size = new System.Drawing.Size(200, 67);
            this.gbx_unit1.TabIndex = 78;
            this.gbx_unit1.TabStop = false;
            this.gbx_unit1.Text = "NIXIE TUBE UNIT 1";
            // 
            // cmbbx_standard_unit1
            // 
            this.cmbbx_standard_unit1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbbx_standard_unit1.FormattingEnabled = true;
            this.cmbbx_standard_unit1.Location = new System.Drawing.Point(100, 18);
            this.cmbbx_standard_unit1.Name = "cmbbx_standard_unit1";
            this.cmbbx_standard_unit1.Size = new System.Drawing.Size(90, 20);
            this.cmbbx_standard_unit1.TabIndex = 79;
            this.cmbbx_standard_unit1.Tag = "0";
            this.cmbbx_standard_unit1.SelectedIndexChanged += new System.EventHandler(this.cmbbx_standard_SelectedIndexChanged);
            // 
            // rbtn_custom_unit1
            // 
            this.rbtn_custom_unit1.AutoSize = true;
            this.rbtn_custom_unit1.Location = new System.Drawing.Point(10, 45);
            this.rbtn_custom_unit1.Name = "rbtn_custom_unit1";
            this.rbtn_custom_unit1.Size = new System.Drawing.Size(83, 16);
            this.rbtn_custom_unit1.TabIndex = 79;
            this.rbtn_custom_unit1.Tag = "0";
            this.rbtn_custom_unit1.Text = "�J�X�^���ݒ�";
            this.rbtn_custom_unit1.UseVisualStyleBackColor = true;
            this.rbtn_custom_unit1.CheckedChanged += new System.EventHandler(this.rbtn_custom_CheckedChanged);
            // 
            // rbtn_standard_unit1
            // 
            this.rbtn_standard_unit1.AutoSize = true;
            this.rbtn_standard_unit1.Location = new System.Drawing.Point(10, 20);
            this.rbtn_standard_unit1.Name = "rbtn_standard_unit1";
            this.rbtn_standard_unit1.Size = new System.Drawing.Size(71, 16);
            this.rbtn_standard_unit1.TabIndex = 79;
            this.rbtn_standard_unit1.Tag = "0";
            this.rbtn_standard_unit1.Text = "�W���ݒ�";
            this.rbtn_standard_unit1.UseVisualStyleBackColor = true;
            this.rbtn_standard_unit1.CheckedChanged += new System.EventHandler(this.rbtn_standard_CheckedChanged);
            // 
            // gbx_unit2
            // 
            this.gbx_unit2.Controls.Add(this.cmbbx_standard_unit2);
            this.gbx_unit2.Controls.Add(this.rbtn_custom_unit2);
            this.gbx_unit2.Controls.Add(this.rbtn_standard_unit2);
            this.gbx_unit2.Location = new System.Drawing.Point(311, 12);
            this.gbx_unit2.Name = "gbx_unit2";
            this.gbx_unit2.Size = new System.Drawing.Size(200, 67);
            this.gbx_unit2.TabIndex = 79;
            this.gbx_unit2.TabStop = false;
            this.gbx_unit2.Text = "NIXIE TUBE UNIT 2";
            // 
            // cmbbx_standard_unit2
            // 
            this.cmbbx_standard_unit2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbbx_standard_unit2.FormattingEnabled = true;
            this.cmbbx_standard_unit2.Location = new System.Drawing.Point(100, 18);
            this.cmbbx_standard_unit2.Name = "cmbbx_standard_unit2";
            this.cmbbx_standard_unit2.Size = new System.Drawing.Size(90, 20);
            this.cmbbx_standard_unit2.TabIndex = 79;
            this.cmbbx_standard_unit2.Tag = "1";
            this.cmbbx_standard_unit2.SelectedIndexChanged += new System.EventHandler(this.cmbbx_standard_SelectedIndexChanged);
            // 
            // rbtn_custom_unit2
            // 
            this.rbtn_custom_unit2.AutoSize = true;
            this.rbtn_custom_unit2.Location = new System.Drawing.Point(10, 45);
            this.rbtn_custom_unit2.Name = "rbtn_custom_unit2";
            this.rbtn_custom_unit2.Size = new System.Drawing.Size(83, 16);
            this.rbtn_custom_unit2.TabIndex = 79;
            this.rbtn_custom_unit2.Tag = "1";
            this.rbtn_custom_unit2.Text = "�J�X�^���ݒ�";
            this.rbtn_custom_unit2.UseVisualStyleBackColor = true;
            this.rbtn_custom_unit2.CheckedChanged += new System.EventHandler(this.rbtn_custom_CheckedChanged);
            // 
            // rbtn_standard_unit2
            // 
            this.rbtn_standard_unit2.AutoSize = true;
            this.rbtn_standard_unit2.Location = new System.Drawing.Point(10, 20);
            this.rbtn_standard_unit2.Name = "rbtn_standard_unit2";
            this.rbtn_standard_unit2.Size = new System.Drawing.Size(71, 16);
            this.rbtn_standard_unit2.TabIndex = 79;
            this.rbtn_standard_unit2.Tag = "1";
            this.rbtn_standard_unit2.Text = "�W���ݒ�";
            this.rbtn_standard_unit2.UseVisualStyleBackColor = true;
            this.rbtn_standard_unit2.CheckedChanged += new System.EventHandler(this.rbtn_standard_CheckedChanged);
            // 
            // gbx_unit3
            // 
            this.gbx_unit3.Controls.Add(this.cmbbx_standard_unit3);
            this.gbx_unit3.Controls.Add(this.rbtn_custom_unit3);
            this.gbx_unit3.Controls.Add(this.rbtn_standard_unit3);
            this.gbx_unit3.Location = new System.Drawing.Point(519, 12);
            this.gbx_unit3.Name = "gbx_unit3";
            this.gbx_unit3.Size = new System.Drawing.Size(200, 67);
            this.gbx_unit3.TabIndex = 80;
            this.gbx_unit3.TabStop = false;
            this.gbx_unit3.Text = "NIXIE TUBE UNIT 3";
            // 
            // cmbbx_standard_unit3
            // 
            this.cmbbx_standard_unit3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbbx_standard_unit3.FormattingEnabled = true;
            this.cmbbx_standard_unit3.Location = new System.Drawing.Point(100, 18);
            this.cmbbx_standard_unit3.Name = "cmbbx_standard_unit3";
            this.cmbbx_standard_unit3.Size = new System.Drawing.Size(90, 20);
            this.cmbbx_standard_unit3.TabIndex = 79;
            this.cmbbx_standard_unit3.Tag = "2";
            this.cmbbx_standard_unit3.SelectedIndexChanged += new System.EventHandler(this.cmbbx_standard_SelectedIndexChanged);
            // 
            // rbtn_custom_unit3
            // 
            this.rbtn_custom_unit3.AutoSize = true;
            this.rbtn_custom_unit3.Location = new System.Drawing.Point(10, 45);
            this.rbtn_custom_unit3.Name = "rbtn_custom_unit3";
            this.rbtn_custom_unit3.Size = new System.Drawing.Size(83, 16);
            this.rbtn_custom_unit3.TabIndex = 79;
            this.rbtn_custom_unit3.Tag = "2";
            this.rbtn_custom_unit3.Text = "�J�X�^���ݒ�";
            this.rbtn_custom_unit3.UseVisualStyleBackColor = true;
            this.rbtn_custom_unit3.CheckedChanged += new System.EventHandler(this.rbtn_custom_CheckedChanged);
            // 
            // rbtn_standard_unit3
            // 
            this.rbtn_standard_unit3.AutoSize = true;
            this.rbtn_standard_unit3.Location = new System.Drawing.Point(10, 20);
            this.rbtn_standard_unit3.Name = "rbtn_standard_unit3";
            this.rbtn_standard_unit3.Size = new System.Drawing.Size(71, 16);
            this.rbtn_standard_unit3.TabIndex = 79;
            this.rbtn_standard_unit3.Tag = "2";
            this.rbtn_standard_unit3.Text = "�W���ݒ�";
            this.rbtn_standard_unit3.UseVisualStyleBackColor = true;
            this.rbtn_standard_unit3.CheckedChanged += new System.EventHandler(this.rbtn_standard_CheckedChanged);
            // 
            // gbx_unit4
            // 
            this.gbx_unit4.Controls.Add(this.cmbbx_standard_unit4);
            this.gbx_unit4.Controls.Add(this.rbtn_custom_unit4);
            this.gbx_unit4.Controls.Add(this.rbtn_standard_unit4);
            this.gbx_unit4.Location = new System.Drawing.Point(727, 12);
            this.gbx_unit4.Name = "gbx_unit4";
            this.gbx_unit4.Size = new System.Drawing.Size(200, 67);
            this.gbx_unit4.TabIndex = 81;
            this.gbx_unit4.TabStop = false;
            this.gbx_unit4.Text = "NIXIE TUBE UNIT 4";
            // 
            // cmbbx_standard_unit4
            // 
            this.cmbbx_standard_unit4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbbx_standard_unit4.FormattingEnabled = true;
            this.cmbbx_standard_unit4.Location = new System.Drawing.Point(100, 18);
            this.cmbbx_standard_unit4.Name = "cmbbx_standard_unit4";
            this.cmbbx_standard_unit4.Size = new System.Drawing.Size(90, 20);
            this.cmbbx_standard_unit4.TabIndex = 79;
            this.cmbbx_standard_unit4.Tag = "3";
            this.cmbbx_standard_unit4.SelectedIndexChanged += new System.EventHandler(this.cmbbx_standard_SelectedIndexChanged);
            // 
            // rbtn_custom_unit4
            // 
            this.rbtn_custom_unit4.AutoSize = true;
            this.rbtn_custom_unit4.Location = new System.Drawing.Point(10, 45);
            this.rbtn_custom_unit4.Name = "rbtn_custom_unit4";
            this.rbtn_custom_unit4.Size = new System.Drawing.Size(83, 16);
            this.rbtn_custom_unit4.TabIndex = 79;
            this.rbtn_custom_unit4.Tag = "3";
            this.rbtn_custom_unit4.Text = "�J�X�^���ݒ�";
            this.rbtn_custom_unit4.UseVisualStyleBackColor = true;
            this.rbtn_custom_unit4.CheckedChanged += new System.EventHandler(this.rbtn_custom_CheckedChanged);
            // 
            // rbtn_standard_unit4
            // 
            this.rbtn_standard_unit4.AutoSize = true;
            this.rbtn_standard_unit4.Location = new System.Drawing.Point(10, 20);
            this.rbtn_standard_unit4.Name = "rbtn_standard_unit4";
            this.rbtn_standard_unit4.Size = new System.Drawing.Size(71, 16);
            this.rbtn_standard_unit4.TabIndex = 79;
            this.rbtn_standard_unit4.Tag = "3";
            this.rbtn_standard_unit4.Text = "�W���ݒ�";
            this.rbtn_standard_unit4.UseVisualStyleBackColor = true;
            this.rbtn_standard_unit4.CheckedChanged += new System.EventHandler(this.rbtn_standard_CheckedChanged);
            // 
            // btn_Set
            // 
            this.btn_Set.Location = new System.Drawing.Point(934, 18);
            this.btn_Set.Name = "btn_Set";
            this.btn_Set.Size = new System.Drawing.Size(73, 60);
            this.btn_Set.TabIndex = 82;
            this.btn_Set.Text = "���s";
            this.btn_Set.UseVisualStyleBackColor = true;
            this.btn_Set.Click += new System.EventHandler(this.btn_Set_Click);
            // 
            // btn_Import
            // 
            this.btn_Import.Location = new System.Drawing.Point(677, 227);
            this.btn_Import.Name = "btn_Import";
            this.btn_Import.Size = new System.Drawing.Size(150, 23);
            this.btn_Import.TabIndex = 83;
            this.btn_Import.Text = "CSV�t�@�C���̓ǂݍ���";
            this.btn_Import.UseVisualStyleBackColor = true;
            this.btn_Import.Click += new System.EventHandler(this.btn_Import_Click);
            // 
            // btn_Export
            // 
            this.btn_Export.Location = new System.Drawing.Point(833, 227);
            this.btn_Export.Name = "btn_Export";
            this.btn_Export.Size = new System.Drawing.Size(150, 23);
            this.btn_Export.TabIndex = 84;
            this.btn_Export.Text = "CSV�t�@�C���֏����o��";
            this.btn_Export.UseVisualStyleBackColor = true;
            this.btn_Export.Click += new System.EventHandler(this.btn_Export_Click);
            // 
            // gbx_loop
            // 
            this.gbx_loop.Controls.Add(this.rbtn_loop);
            this.gbx_loop.Controls.Add(this.rbtn_one);
            this.gbx_loop.Location = new System.Drawing.Point(10, 12);
            this.gbx_loop.Name = "gbx_loop";
            this.gbx_loop.Size = new System.Drawing.Size(85, 67);
            this.gbx_loop.TabIndex = 85;
            this.gbx_loop.TabStop = false;
            this.gbx_loop.Text = "�J��Ԃ�";
            // 
            // rbtn_loop
            // 
            this.rbtn_loop.AutoSize = true;
            this.rbtn_loop.Location = new System.Drawing.Point(13, 45);
            this.rbtn_loop.Name = "rbtn_loop";
            this.rbtn_loop.Size = new System.Drawing.Size(52, 16);
            this.rbtn_loop.TabIndex = 86;
            this.rbtn_loop.TabStop = true;
            this.rbtn_loop.Tag = "1";
            this.rbtn_loop.Text = "���[�v";
            this.rbtn_loop.UseVisualStyleBackColor = true;
            this.rbtn_loop.CheckedChanged += new System.EventHandler(this.rbtn_Loop_Type_CheckedChanged);
            // 
            // rbtn_one
            // 
            this.rbtn_one.AutoSize = true;
            this.rbtn_one.Location = new System.Drawing.Point(13, 20);
            this.rbtn_one.Name = "rbtn_one";
            this.rbtn_one.Size = new System.Drawing.Size(41, 16);
            this.rbtn_one.TabIndex = 86;
            this.rbtn_one.TabStop = true;
            this.rbtn_one.Tag = "0";
            this.rbtn_one.Text = "1��";
            this.rbtn_one.UseVisualStyleBackColor = true;
            this.rbtn_one.CheckedChanged += new System.EventHandler(this.rbtn_Loop_Type_CheckedChanged);
            // 
            // gbx_Custom_Setting
            // 
            this.gbx_Custom_Setting.BackColor = System.Drawing.Color.Transparent;
            this.gbx_Custom_Setting.Controls.Add(this.picbx_Custom4);
            this.gbx_Custom_Setting.Controls.Add(this.picbx_Custom3);
            this.gbx_Custom_Setting.Controls.Add(this.dgv_DispSetData);
            this.gbx_Custom_Setting.Controls.Add(this.btn_Export);
            this.gbx_Custom_Setting.Controls.Add(this.picbx_Custom2);
            this.gbx_Custom_Setting.Controls.Add(this.btn_Import);
            this.gbx_Custom_Setting.Controls.Add(this.picbx_Custom1);
            this.gbx_Custom_Setting.Location = new System.Drawing.Point(10, 105);
            this.gbx_Custom_Setting.Name = "gbx_Custom_Setting";
            this.gbx_Custom_Setting.Size = new System.Drawing.Size(998, 258);
            this.gbx_Custom_Setting.TabIndex = 86;
            this.gbx_Custom_Setting.TabStop = false;
            this.gbx_Custom_Setting.Text = "�J�X�^���ݒ�l";
            // 
            // picbx_Custom4
            // 
            this.picbx_Custom4.Image = global::NixieKit.Properties.Resources.Custom_no4;
            this.picbx_Custom4.Location = new System.Drawing.Point(753, 16);
            this.picbx_Custom4.Name = "picbx_Custom4";
            this.picbx_Custom4.Size = new System.Drawing.Size(211, 24);
            this.picbx_Custom4.TabIndex = 125;
            this.picbx_Custom4.TabStop = false;
            this.picbx_Custom4.Visible = false;
            // 
            // picbx_Custom3
            // 
            this.picbx_Custom3.Image = global::NixieKit.Properties.Resources.Custom_no3;
            this.picbx_Custom3.Location = new System.Drawing.Point(541, 16);
            this.picbx_Custom3.Name = "picbx_Custom3";
            this.picbx_Custom3.Size = new System.Drawing.Size(211, 24);
            this.picbx_Custom3.TabIndex = 126;
            this.picbx_Custom3.TabStop = false;
            this.picbx_Custom3.Visible = false;
            // 
            // picbx_Custom2
            // 
            this.picbx_Custom2.Image = global::NixieKit.Properties.Resources.Custom_no2;
            this.picbx_Custom2.Location = new System.Drawing.Point(329, 16);
            this.picbx_Custom2.Name = "picbx_Custom2";
            this.picbx_Custom2.Size = new System.Drawing.Size(211, 24);
            this.picbx_Custom2.TabIndex = 124;
            this.picbx_Custom2.TabStop = false;
            this.picbx_Custom2.Visible = false;
            // 
            // picbx_Custom1
            // 
            this.picbx_Custom1.Image = global::NixieKit.Properties.Resources.Custom_no1;
            this.picbx_Custom1.Location = new System.Drawing.Point(117, 16);
            this.picbx_Custom1.Name = "picbx_Custom1";
            this.picbx_Custom1.Size = new System.Drawing.Size(211, 24);
            this.picbx_Custom1.TabIndex = 123;
            this.picbx_Custom1.TabStop = false;
            this.picbx_Custom1.Visible = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(807, 632);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 23);
            this.button1.TabIndex = 87;
            this.button1.Text = "�_�ŊԊu�ݒ�";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // StatusBox_lbl2
            // 
            this.StatusBox_lbl2.AutoSize = true;
            this.StatusBox_lbl2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.StatusBox_lbl2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.StatusBox_lbl2.Location = new System.Drawing.Point(17, 530);
            this.StatusBox_lbl2.Name = "StatusBox_lbl2";
            this.StatusBox_lbl2.Size = new System.Drawing.Size(62, 12);
            this.StatusBox_lbl2.TabIndex = 121;
            this.StatusBox_lbl2.Text = "Information";
            // 
            // StatusBox_lbl
            // 
            this.StatusBox_lbl.AutoSize = true;
            this.StatusBox_lbl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.StatusBox_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.StatusBox_lbl.Location = new System.Drawing.Point(891, 530);
            this.StatusBox_lbl.Name = "StatusBox_lbl";
            this.StatusBox_lbl.Size = new System.Drawing.Size(79, 12);
            this.StatusBox_lbl.TabIndex = 120;
            this.StatusBox_lbl.Text = "�f�o�C�X���ڑ�";
            // 
            // Status_NC_pb
            // 
            this.Status_NC_pb.BackColor = System.Drawing.Color.Transparent;
            this.Status_NC_pb.Image = global::NixieKit.Properties.Resources.USBOFF;
            this.Status_NC_pb.Location = new System.Drawing.Point(985, 531);
            this.Status_NC_pb.Name = "Status_NC_pb";
            this.Status_NC_pb.Size = new System.Drawing.Size(27, 8);
            this.Status_NC_pb.TabIndex = 122;
            this.Status_NC_pb.TabStop = false;
            this.Status_NC_pb.Visible = false;
            // 
            // Status_C_pb
            // 
            this.Status_C_pb.BackColor = System.Drawing.Color.Transparent;
            this.Status_C_pb.Image = global::NixieKit.Properties.Resources.USBON;
            this.Status_C_pb.Location = new System.Drawing.Point(985, 531);
            this.Status_C_pb.Name = "Status_C_pb";
            this.Status_C_pb.Size = new System.Drawing.Size(27, 8);
            this.Status_C_pb.TabIndex = 119;
            this.Status_C_pb.TabStop = false;
            this.Status_C_pb.Visible = false;
            // 
            // lbl_Set_Date
            // 
            this.lbl_Set_Date.ImageIndex = 0;
            this.lbl_Set_Date.ImageList = this.imageList_Set_Date;
            this.lbl_Set_Date.Location = new System.Drawing.Point(830, 477);
            this.lbl_Set_Date.Name = "lbl_Set_Date";
            this.lbl_Set_Date.Size = new System.Drawing.Size(167, 37);
            this.lbl_Set_Date.TabIndex = 123;
            this.lbl_Set_Date.MouseLeave += new System.EventHandler(this.lbl_Set_Date_MouseLeave);
            this.lbl_Set_Date.Click += new System.EventHandler(this.lbl_Set_Date_Click);
            this.lbl_Set_Date.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lbl_Set_Date_MouseDown);
            this.lbl_Set_Date.MouseUp += new System.Windows.Forms.MouseEventHandler(this.lbl_Set_Date_MouseUp);
            this.lbl_Set_Date.MouseEnter += new System.EventHandler(this.lbl_Set_Date_MouseEnter);
            // 
            // imageList_Set_Date
            // 
            this.imageList_Set_Date.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList_Set_Date.ImageStream")));
            this.imageList_Set_Date.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList_Set_Date.Images.SetKeyName(0, "DateSet_Normal.png");
            this.imageList_Set_Date.Images.SetKeyName(1, "DateSet_MouseOn.png");
            this.imageList_Set_Date.Images.SetKeyName(2, "DateSet_Click.png");
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1018, 722);
            this.Controls.Add(this.Status_NC_pb);
            this.Controls.Add(this.Status_C_pb);
            this.Controls.Add(this.lbl_Set_Date);
            this.Controls.Add(this.StatusBox_lbl2);
            this.Controls.Add(this.StatusBox_lbl);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.gbx_Custom_Setting);
            this.Controls.Add(this.gbx_loop);
            this.Controls.Add(this.btn_Set);
            this.Controls.Add(this.gbx_unit4);
            this.Controls.Add(this.gbx_unit3);
            this.Controls.Add(this.gbx_unit2);
            this.Controls.Add(this.gbx_unit1);
            this.Controls.Add(this.btn_Read_Number);
            this.Controls.Add(this.btn_Set_Number_All);
            this.Controls.Add(this.btn_Set_Number);
            this.Controls.Add(this.cmbbox_Unit);
            this.Controls.Add(this.txtbox_Num4);
            this.Controls.Add(this.txtbox_Num3);
            this.Controls.Add(this.txtbox_Num2);
            this.Controls.Add(this.txtbox_Num1);
            this.Controls.Add(this.lbl_FW_Version);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.connect_status_lbl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "�j�L�V�[�ǃL�b�g �R���g���[�����j�b�g�p configuration tool Ver1.0.0";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_DispSetData)).EndInit();
            this.gbx_unit1.ResumeLayout(false);
            this.gbx_unit1.PerformLayout();
            this.gbx_unit2.ResumeLayout(false);
            this.gbx_unit2.PerformLayout();
            this.gbx_unit3.ResumeLayout(false);
            this.gbx_unit3.PerformLayout();
            this.gbx_unit4.ResumeLayout(false);
            this.gbx_unit4.PerformLayout();
            this.gbx_loop.ResumeLayout(false);
            this.gbx_loop.PerformLayout();
            this.gbx_Custom_Setting.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Custom4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Custom3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Custom2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Custom1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_NC_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_C_pb)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker ReadWriteThread;
        private System.Windows.Forms.Timer FormUpdateTimer;
        private System.Windows.Forms.Label connect_status_lbl;
        private System.Windows.Forms.Label debug01_lbl;
        private System.Windows.Forms.Label debug02_lbl;
        private System.Windows.Forms.Label debug03_lbl;
        private System.Windows.Forms.Label colum_lbl;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label lbl_FW_Version;
        private System.Windows.Forms.TextBox txtbox_Num1;
        private System.Windows.Forms.TextBox txtbox_Num2;
        private System.Windows.Forms.TextBox txtbox_Num3;
        private System.Windows.Forms.TextBox txtbox_Num4;
        private System.Windows.Forms.ComboBox cmbbox_Unit;
        private System.Windows.Forms.Button btn_Set_Number;
        private System.Windows.Forms.Button btn_Set_Number_All;
        private System.Windows.Forms.Button btn_Read_Number;
        private System.Windows.Forms.DataGridView dgv_DispSetData;
        private System.Windows.Forms.GroupBox gbx_unit1;
        private System.Windows.Forms.ComboBox cmbbx_standard_unit1;
        private System.Windows.Forms.RadioButton rbtn_custom_unit1;
        private System.Windows.Forms.RadioButton rbtn_standard_unit1;
        private System.Windows.Forms.GroupBox gbx_unit2;
        private System.Windows.Forms.ComboBox cmbbx_standard_unit2;
        private System.Windows.Forms.RadioButton rbtn_custom_unit2;
        private System.Windows.Forms.RadioButton rbtn_standard_unit2;
        private System.Windows.Forms.GroupBox gbx_unit3;
        private System.Windows.Forms.ComboBox cmbbx_standard_unit3;
        private System.Windows.Forms.RadioButton rbtn_custom_unit3;
        private System.Windows.Forms.RadioButton rbtn_standard_unit3;
        private System.Windows.Forms.GroupBox gbx_unit4;
        private System.Windows.Forms.ComboBox cmbbx_standard_unit4;
        private System.Windows.Forms.RadioButton rbtn_custom_unit4;
        private System.Windows.Forms.RadioButton rbtn_standard_unit4;
        private System.Windows.Forms.Button btn_Set;
        private System.Windows.Forms.Button btn_Import;
        private System.Windows.Forms.Button btn_Export;
        private System.Windows.Forms.GroupBox gbx_loop;
        private System.Windows.Forms.RadioButton rbtn_loop;
        private System.Windows.Forms.RadioButton rbtn_one;
        private System.Windows.Forms.GroupBox gbx_Custom_Setting;
        private System.Windows.Forms.DataGridViewTextBoxColumn time;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit1_1;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit1_2;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit1_3;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit1_4;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit2_1;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit2_2;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit2_3;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit2_4;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit3_1;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit3_2;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit3_3;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit3_4;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit4_1;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit4_2;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit4_3;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit4_4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label StatusBox_lbl2;
        private System.Windows.Forms.Label StatusBox_lbl;
        private System.Windows.Forms.PictureBox Status_C_pb;
        private System.Windows.Forms.PictureBox Status_NC_pb;
        private System.Windows.Forms.PictureBox picbx_Custom1;
        private System.Windows.Forms.PictureBox picbx_Custom4;
        private System.Windows.Forms.PictureBox picbx_Custom3;
        private System.Windows.Forms.PictureBox picbx_Custom2;
        private System.Windows.Forms.Label lbl_Set_Date;
        private System.Windows.Forms.ImageList imageList_Set_Date;
    }
}

