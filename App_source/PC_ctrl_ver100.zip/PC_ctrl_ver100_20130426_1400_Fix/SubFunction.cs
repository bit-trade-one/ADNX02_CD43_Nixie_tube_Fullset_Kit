﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace NixieKit
{
    class SubFunction
    {
        public static int CsvToStringArray(string p_csvText, out string[] o_csv_data, out int o_data_num)
        {
            int i_ret = 0;
            int csvTextLength;
            int startPos = 0, endPos = 0;
            string field = "";
            ArrayList al_tmp = new ArrayList();

            o_csv_data = null;
            o_data_num = 0;
            try
            {

                // CSV分割
                //前後の改行を削除しておく
                p_csvText = p_csvText.Trim(new char[] { '\r', '\n' });

                csvTextLength = p_csvText.Length;

                while (true)
                {
                    //SP,TABを飛ばす
                    while (startPos < csvTextLength &&
                        (p_csvText[startPos] == ' ' || p_csvText[startPos] == '\t'))
                    {
                        startPos++;
                    }

                    //データの最後の位置を取得
                    if (startPos < csvTextLength && p_csvText[startPos] == '"')
                    {
                        //"で囲まれているとき
                        //最後の"を探す
                        endPos = startPos;
                        while (true)
                        {
                            endPos = p_csvText.IndexOf('"', endPos + 1);
                            if (endPos < 0)
                            {
                                throw new ApplicationException("\"が不正");
                            }
                            //"が2つ続かない時は終了
                            if (endPos + 1 == csvTextLength || p_csvText[endPos + 1] != '"')
                            {
                                break;
                            }
                            //"が2つ続く
                            endPos++;
                        }

                        //一つのフィールドを取り出す
                        field = p_csvText.Substring(startPos, endPos - startPos + 1);
                        //前後の"を取る
                        field = field.Substring(1, field.Length - 2);
                        //""を"にする
                        field = field.Replace("\"\"", "\"");

                        endPos++;
                        //空白を飛ばす
                        while (endPos < csvTextLength &&
                            p_csvText[endPos] != ',' && p_csvText[endPos] != '\n')
                        {
                            endPos++;
                        }
                    }
                    else
                    {
                        //"で囲まれていない
                        //カンマか改行の位置
                        endPos = startPos;
                        while (endPos < csvTextLength &&
                            p_csvText[endPos] != ',' && p_csvText[endPos] != '\n')
                        {
                            endPos++;
                        }

                        //一つのフィールドを取り出す
                        field = p_csvText.Substring(startPos, endPos - startPos);
                        //後の空白を削除
                        field = field.TrimEnd();
                    }

                    //フィールドの追加
                    al_tmp.Add(field);

                    //行の終了か調べる
                    if (endPos >= csvTextLength || p_csvText[endPos] == '\n')
                    {
                        //行の終了
                        al_tmp.TrimToSize();

                        //終了
                        break;
                    }

                    //次のデータの開始位置
                    startPos = endPos + 1;
                }


                // 出力データセット
                o_data_num = al_tmp.Count;
                o_csv_data = new string[o_data_num];
                for (int fi = 0; fi < o_data_num; fi++)
                {
                    o_csv_data[fi] = (string)al_tmp[fi];
                }

            }
            catch
            {
                i_ret = -1;
            }
            return i_ret;
        }
        public static int StringArrayToCsv(string[] p_csv_data, out string o_csvText)
        {
            int i_ret = 0;
            string field = "";

            o_csvText = "";
            try
            {

                // データ数
                int data_count = p_csv_data.Length;
                for (int fi = 0; fi < data_count; fi++ )
                {
                    field = p_csv_data[fi];

                    //"を""にする
                    field = field.Replace("\"", "\"\"");

                    // カンマ追加
                    if( fi > 0)
                    {
                        o_csvText += ",";
                    }

                    //データを""で囲む
                    field = "\"" + field + "\"";

                    o_csvText += field;
                }
            }
            catch
            {
                i_ret = -1;
            }
            return i_ret;
        }
    }
}
