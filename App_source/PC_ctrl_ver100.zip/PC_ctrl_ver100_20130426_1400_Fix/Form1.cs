//-------------------------------------------------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
/********************************************************************
 FileName:		Form1.cs
 Dependencies:	When compiled, needs .NET framework 2.0 redistributable to run.
 Hardware:		Need a free USB port to connect USB peripheral device
				programmed with appropriate Generic HID firmware.  VID and
				PID in firmware must match the VID and PID in this
				program.
 Compiler:  	Microsoft Visual C# 2005 Express Edition (or better)
 Company:		Microchip Technology, Inc.

 Software License Agreement:

 The software supplied herewith by Microchip Technology Incorporated
 (the �Company�E for its PIC� Microcontroller is intended and
 supplied to you, the Company�s customer, for use solely and
 exclusively with Microchip PIC Microcontroller products. The
 software is owned by the Company and/or its supplier, and is
 protected under applicable copyright laws. All rights are reserved.
 Any use in violation of the foregoing restrictions may subject the
 user to criminal sanctions under applicable laws, as well as to
 civil liability for the breach of the terms and conditions of this
 license.

 THIS SOFTWARE IS PROVIDED IN AN �AS IS�ECONDITION. NO WARRANTIES,
 WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.

********************************************************************
 File Description:

 Change History:
  Rev   Date         Description
  2.5a	07/17/2009	 Initial Release.  Ported from HID PnP Demo
                     application source, which was originally 
                     written in MSVC++ 2005 Express Edition.
********************************************************************
NOTE:	All user made code contained in this project is in the Form1.cs file.
		All other code and files were generated automatically by either the
		new project wizard, or by the development environment (ex: code is
		automatically generated if you create a new button on the form, and
		then double click on it, which creates a click event handler
		function).  User developed code (code not developed by the IDE) has
        been marked in "cut and paste blocks" to make it easier to identify.
********************************************************************/

//NOTE: In order for this program to "find" a USB device with a given VID and PID, 
//both the VID and PID in the USB device descriptor (in the USB firmware on the 
//microcontroller), as well as in this PC application source code, must match.
//To change the VID/PID in this PC application source code, scroll down to the 
//CheckIfPresentAndGetUSBDevicePath() function, and change the line that currently
//reads:

//   String DeviceIDToFind = "Vid_04d8&Pid_003f";


//NOTE 2: This C# program makes use of several functions in setupapi.dll and
//other Win32 DLLs.  However, one cannot call the functions directly in a 
//32-bit DLL if the project is built in "Any CPU" mode, when run on a 64-bit OS.
//When configured to build an "Any CPU" executable, the executable will "become"
//a 64-bit executable when run on a 64-bit OS.  On a 32-bit OS, it will run as 
//a 32-bit executable, and the pointer sizes and other aspects of this 
//application will be compatible with calling 32-bit DLLs.

//Therefore, on a 64-bit OS, this application will not work unless it is built in
//"x86" mode.  When built in this mode, the exectuable always runs in 32-bit mode
//even on a 64-bit OS.  This allows this application to make 32-bit DLL function 
//calls, when run on either a 32-bit or 64-bit OS.

//By default, on a new project, C# normally wants to build in "Any CPU" mode.  
//To switch to "x86" mode, open the "Configuration Manager" window.  In the 
//"Active solution platform:" drop down box, select "x86".  If this option does
//not appear, select: "<New...>" and then select the x86 option in the 
//"Type or select the new platform:" drop down box.  

//-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------



using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32.SafeHandles;
using System.Runtime.InteropServices;
using System.Threading;


namespace NixieKit
{
    public partial class Form1 : Form
    {

        //internal const bool __DEBUG_FLAG__ = true;    // �f�o�b�O��
        internal const bool __DEBUG_FLAG__ = false;     // �����[�X��

        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
        internal const string DEF_VID_PID = "Vid_22EA&Pid_002B";
        //Constant definitions from setupapi.h, which we aren't allowed to include directly since this is C#
        internal const uint DIGCF_PRESENT = 0x02;
        internal const uint DIGCF_DEVICEINTERFACE = 0x10;
        //Constants for CreateFile() and other file I/O functions
        internal const short FILE_ATTRIBUTE_NORMAL = 0x80;
        internal const short INVALID_HANDLE_VALUE = -1;
        internal const uint GENERIC_READ = 0x80000000;
        internal const uint GENERIC_WRITE = 0x40000000;
        internal const uint CREATE_NEW = 1;
        internal const uint CREATE_ALWAYS = 2;
        internal const uint OPEN_EXISTING = 3;
        internal const uint FILE_SHARE_READ = 0x00000001;
        internal const uint FILE_SHARE_WRITE = 0x00000002;
        //Constant definitions for certain WM_DEVICECHANGE messages
        internal const uint WM_DEVICECHANGE = 0x0219;
        internal const uint DBT_DEVICEARRIVAL = 0x8000;
        internal const uint DBT_DEVICEREMOVEPENDING = 0x8003;
        internal const uint DBT_DEVICEREMOVECOMPLETE = 0x8004;
        internal const uint DBT_CONFIGCHANGED = 0x0018;
        //Other constant definitions
        internal const uint DBT_DEVTYP_DEVICEINTERFACE = 0x05;
        internal const uint DEVICE_NOTIFY_WINDOW_HANDLE = 0x00;
        internal const uint ERROR_SUCCESS = 0x00;
        internal const uint ERROR_NO_MORE_ITEMS = 0x00000103;
        internal const uint SPDRP_HARDWAREID = 0x00000001;

        //Various structure definitions for structures that this code will be using
        internal struct SP_DEVICE_INTERFACE_DATA
        {
            internal uint cbSize;               //DWORD
            internal Guid InterfaceClassGuid;   //GUID
            internal uint Flags;                //DWORD
            internal uint Reserved;             //ULONG_PTR MSDN says ULONG_PTR is "typedef unsigned __int3264 ULONG_PTR;"  
        }

        internal struct SP_DEVICE_INTERFACE_DETAIL_DATA
        {
            internal uint cbSize;               //DWORD
            internal char[] DevicePath;         //TCHAR array of any size
        }
        
        internal struct SP_DEVINFO_DATA
        {
            internal uint cbSize;       //DWORD
            internal Guid ClassGuid;    //GUID
            internal uint DevInst;      //DWORD
            internal uint Reserved;     //ULONG_PTR  MSDN says ULONG_PTR is "typedef unsigned __int3264 ULONG_PTR;"  
        }

        internal struct DEV_BROADCAST_DEVICEINTERFACE
        {
            internal uint dbcc_size;            //DWORD
            internal uint dbcc_devicetype;      //DWORD
            internal uint dbcc_reserved;        //DWORD
            internal Guid dbcc_classguid;       //GUID
            internal char[] dbcc_name;          //TCHAR array
        }

        //internal struct SP_COMMTIMEOUTS
        //{
        //    internal uint ReadIntervalTimeout;
	    //    internal uint ReadTotalTimeoutMultiplier;
	    //    internal uint ReadTotalTimeoutConstant;
	    //    internal uint WriteTotalTimeoutMultiplier;
	    //    internal uint WriteTotalTimeoutConstant;
        //}

        internal struct ST_APP_SETTING_DATA
        {
            internal byte loop_type;
            internal int[] standard_select_idx;
            internal byte[] setting_type;
            internal byte[,] standard_setting_number;
            internal byte[,] standard_setting_control1;
            internal byte[,] standard_setting_control2;
            internal DateTime dt_start_time;
            internal DateTime dt_next_exe_time;
            internal int exe_idx;
            internal void init(int p_unit_num, int p_nixie_num)
            {
                loop_type = 0;
                standard_select_idx = new int[p_unit_num];
                setting_type = new byte[p_unit_num];
                standard_setting_number = new byte[p_unit_num, p_nixie_num];
                standard_setting_control1 = new byte[p_unit_num, p_nixie_num];
                standard_setting_control2 = new byte[p_unit_num, p_nixie_num];

                dt_start_time = DateTime.Now;
                dt_next_exe_time = DateTime.Now;
                exe_idx = 0;
            }
        }
        internal struct ST_DISP_CUSTOM_DATA
        {
            internal uint data_num;
            internal uint time;
            internal string[,] custom_data;
            internal void init(uint p_time, int p_unit_num, int p_nixie_num)
            {
                data_num = 1 + (uint)(p_unit_num * p_nixie_num);
                time = p_time;
                custom_data = new string[p_unit_num, p_nixie_num];
                for (int fi = 0; fi < p_unit_num; fi++ )
                {
                    for (int fj = 0; fj < p_nixie_num; fj++)
                    {
                        custom_data[fi, fj] = "";
                    }
                }
            }
        }

        //DLL Imports.  Need these to access various C style unmanaged functions contained in their respective DLL files.
        //--------------------------------------------------------------------------------------------------------------
        //Returns a HDEVINFO type for a device information set.  We will need the 
        //HDEVINFO as in input parameter for calling many of the other SetupDixxx() functions.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern IntPtr SetupDiGetClassDevs(
            ref Guid ClassGuid,     //LPGUID    Input: Need to supply the class GUID. 
            IntPtr Enumerator,      //PCTSTR    Input: Use NULL here, not important for our purposes
            IntPtr hwndParent,      //HWND      Input: Use NULL here, not important for our purposes
            uint Flags);            //DWORD     Input: Flags describing what kind of filtering to use.

	    //Gives us "PSP_DEVICE_INTERFACE_DATA" which contains the Interface specific GUID (different
	    //from class GUID).  We need the interface GUID to get the device path.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiEnumDeviceInterfaces(
            IntPtr DeviceInfoSet,           //Input: Give it the HDEVINFO we got from SetupDiGetClassDevs()
            IntPtr DeviceInfoData,          //Input (optional)
            ref Guid InterfaceClassGuid,    //Input 
            uint MemberIndex,               //Input: "Index" of the device you are interested in getting the path for.
            ref SP_DEVICE_INTERFACE_DATA DeviceInterfaceData);    //Output: This function fills in an "SP_DEVICE_INTERFACE_DATA" structure.

        //SetupDiDestroyDeviceInfoList() frees up memory by destroying a DeviceInfoList
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiDestroyDeviceInfoList(
            IntPtr DeviceInfoSet);          //Input: Give it a handle to a device info list to deallocate from RAM.

        //SetupDiEnumDeviceInfo() fills in an "SP_DEVINFO_DATA" structure, which we need for SetupDiGetDeviceRegistryProperty()
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiEnumDeviceInfo(
            IntPtr DeviceInfoSet,
            uint MemberIndex,
            ref SP_DEVINFO_DATA DeviceInterfaceData);

        //SetupDiGetDeviceRegistryProperty() gives us the hardware ID, which we use to check to see if it has matching VID/PID
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiGetDeviceRegistryProperty(
            IntPtr DeviceInfoSet,
            ref SP_DEVINFO_DATA DeviceInfoData,
            uint Property,
            ref uint PropertyRegDataType,
            IntPtr PropertyBuffer,
            uint PropertyBufferSize,
            ref uint RequiredSize);

        //SetupDiGetDeviceInterfaceDetail() gives us a device path, which is needed before CreateFile() can be used.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiGetDeviceInterfaceDetail(
            IntPtr DeviceInfoSet,                   //Input: Wants HDEVINFO which can be obtained from SetupDiGetClassDevs()
            ref SP_DEVICE_INTERFACE_DATA DeviceInterfaceData,                    //Input: Pointer to an structure which defines the device interface.  
            IntPtr  DeviceInterfaceDetailData,      //Output: Pointer to a SP_DEVICE_INTERFACE_DETAIL_DATA structure, which will receive the device path.
            uint DeviceInterfaceDetailDataSize,     //Input: Number of bytes to retrieve.
            ref uint RequiredSize,                  //Output (optional): The number of bytes needed to hold the entire struct 
            IntPtr DeviceInfoData);                 //Output (optional): Pointer to a SP_DEVINFO_DATA structure

        //Overload for SetupDiGetDeviceInterfaceDetail().  Need this one since we can't pass NULL pointers directly in C#.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiGetDeviceInterfaceDetail(
            IntPtr DeviceInfoSet,                   //Input: Wants HDEVINFO which can be obtained from SetupDiGetClassDevs()
            ref SP_DEVICE_INTERFACE_DATA DeviceInterfaceData,               //Input: Pointer to an structure which defines the device interface.  
            IntPtr DeviceInterfaceDetailData,       //Output: Pointer to a SP_DEVICE_INTERFACE_DETAIL_DATA structure, which will contain the device path.
            uint DeviceInterfaceDetailDataSize,     //Input: Number of bytes to retrieve.
            IntPtr RequiredSize,                    //Output (optional): Pointer to a DWORD to tell you the number of bytes needed to hold the entire struct 
            IntPtr DeviceInfoData);                 //Output (optional): Pointer to a SP_DEVINFO_DATA structure

        //Need this function for receiving all of the WM_DEVICECHANGE messages.  See MSDN documentation for
        //description of what this function does/how to use it. Note: name is remapped "RegisterDeviceNotificationUM" to
        //avoid possible build error conflicts.
        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern IntPtr RegisterDeviceNotification(
            IntPtr hRecipient,
            IntPtr NotificationFilter,
            uint Flags);

        //Takes in a device path and opens a handle to the device.
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern SafeFileHandle CreateFile(
            string lpFileName,
            uint dwDesiredAccess,
            uint dwShareMode, 
            IntPtr lpSecurityAttributes, 
            uint dwCreationDisposition,
            uint dwFlagsAndAttributes, 
            IntPtr hTemplateFile);

        //Uses a handle (created with CreateFile()), and lets us write USB data to the device.
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern bool WriteFile(
            SafeFileHandle hFile,
            byte[] lpBuffer,
            uint nNumberOfBytesToWrite,
            ref uint lpNumberOfBytesWritten,
            IntPtr lpOverlapped);

        //Uses a handle (created with CreateFile()), and lets us read USB data from the device.
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern bool ReadFile(
            SafeFileHandle hFile,
            IntPtr lpBuffer,
            uint nNumberOfBytesToRead,
            ref uint lpNumberOfBytesRead,
            IntPtr lpOverlapped);

        //
        //[DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        //static extern bool SetCommTimeouts(
        //    SafeFileHandle hFile,
        //    ref SP_COMMTIMEOUTS lpCommTimeouts);


	    //--------------- Global Varibles Section ------------------
	    //USB related variables that need to have wide scope.
	    bool AttachedState = false;						//Need to keep track of the USB device attachment status for proper plug and play operation.
	    bool AttachedButBroken = false;
        bool AttachedFirstTime = true;
        SafeFileHandle WriteHandleToUSBDevice = null;
        SafeFileHandle ReadHandleToUSBDevice = null;
        String DevicePath = null;   //Need the find the proper device path before you can open file handles.
        int Now_Background_image = -1;  //�ǂ����̔w�i���\������Ă��邩�B0:���ڑ� 1:�ڑ��ς�

        int[] Debug_Array = new int[16];    //DEBUG
        int[] Debug_Arr2 = new int[16];

        ST_APP_SETTING_DATA app_setting_data;
        const string c_KEY_LOOP_SETTING = "LOOP_SETTING";
        const byte c_LOOP_TYPE_ID_ONE = 0;
        const byte c_LOOP_TYPE_ID_LOOP = 1;
        const string c_KEY_SETTING_TYPE = "SETTING_TYPE";
        const byte c_SETTING_TYPE_ID_STANDARD = 0;
        const byte c_SETTING_TYPE_ID_CUSTOM = 1;
        const string c_KEY_NUMBER = "NUMBER";
        const string c_KEY_CONTROL1 = "CONTROL1";
        const string c_KEY_CONTROL2 = "CONTROL2";

        const string c_APPLICATION_NAME = "�j�L�V�[�ǃL�b�g";
        const string c_VERSION = "FW Version ";
        bool VersionReadReq = true;
        bool VersionReadComp = false;
        byte[] version_buff = new byte[64];

        bool b_TimeSet_flag = false;
        int[] Time_Set_Num = new int[7];

        bool b_NumberSet_flag = false;
        bool b_All_NumberSet_flag = false;
        const byte c_NIXIE_TUBE_NUM = 4;                // �j�L�V�[�ǃ��j�b�g�̃j�L�V�[�ǐ�
        const byte c_DISP_NUMBER_NONE = 0xFF;           // �\���Ȃ��i�����j�̏ꍇ�ɐݒ肷�鐔�l
        byte[,] Set_Number = new byte[c_NIXIE_MAX_UNIT_NUM,c_NIXIE_TUBE_NUM];
        byte[,] Set_Control1 = new byte[c_NIXIE_MAX_UNIT_NUM,c_NIXIE_TUBE_NUM];
        byte[,] Set_Control2 = new byte[c_NIXIE_MAX_UNIT_NUM,c_NIXIE_TUBE_NUM];
        byte Set_Nixie_Unit = 0;
        const byte c_NIXIE_MAX_UNIT_NUM = 4;            // �j�L�V�[�ǃ��j�b�g�̐ڑ��ő吔
        TextBox[] my_Set_Numbers;
        bool b_Blink_Interval_Set_flag = false;

        bool b_NumberGet_req_flag = false;
        bool b_NumberGet_read_flag = false;
        byte[] Get_Number = new byte[c_NIXIE_TUBE_NUM];
        byte[] Get_Control1 = new byte[c_NIXIE_TUBE_NUM];
        byte[] Get_Control2 = new byte[c_NIXIE_TUBE_NUM];
        byte Get_Nixie_Unit = 0;

        List<ST_DISP_CUSTOM_DATA> list_Custom_Data = new List<ST_DISP_CUSTOM_DATA>();
        const uint c_CUSTOM_DATA_DEFAULT_TIME = 100;            // �J�X�^���ݒ�̃f�t�H���g����

        bool b_exe_flag = false;
        const string C_EXE_STRING = "�ݒ�/���s";
        const string C_NON_EXE_STRING = "��~";
        const uint C_INTERVAL_TIME_UNIT = 100;

        // �W���ݒ�
        const int C_STANDARD_SETTING_NUM = 5;   // �W���ݒ萔
        // �I����
        string[] Standard_Setting_Item_Name = new string[C_STANDARD_SETTING_NUM] { "�N4��(yyyy.)", "����(MM.dd.)", "����(HH.mm)", "����(HH.m)", "���b(m.ss)" };
        // �ݒ�l NUMBER
        byte[,] Standard_Setting_Number = new byte[C_STANDARD_SETTING_NUM, c_NIXIE_TUBE_NUM] { { 0x00, 0x00, 0x00, 0x00 },
                                                                                                { 0x00, 0x00, 0x00, 0x00 },
                                                                                                { 0x00, 0x00, 0x00, 0x00 },
                                                                                                { 0x00, 0x00, 0xFF, 0x00 },
                                                                                                { 0x00, 0xFF, 0x00, 0x00 } };
        // �ݒ�l CONTROL1
        byte[,] Standard_Setting_Control1 = new byte[C_STANDARD_SETTING_NUM, c_NIXIE_TUBE_NUM] { { 0x10, 0x10, 0x10, 0x11 },
                                                                                                { 0x10, 0x11, 0x10, 0x11 },
                                                                                                { 0x10, 0x15, 0x10, 0x10 },
                                                                                                { 0x10, 0x10, 0x11, 0x10 },
                                                                                                { 0x10, 0x11, 0x10, 0x10 } };
        // �ݒ�l CONTROL2
        byte[,] Standard_Setting_Control2 = new byte[C_STANDARD_SETTING_NUM, c_NIXIE_TUBE_NUM] { { 0x01, 0x02, 0x03, 0x04 },
                                                                                                { 0x05, 0x06, 0x07, 0x08 },
                                                                                                { 0x09, 0x1A, 0x0B, 0x0C },
                                                                                                { 0x09, 0x0A, 0x00, 0x0B },
                                                                                                { 0x0C, 0x00, 0x0D, 0x0E } };
        RadioButton[] my_rbn_loop_type;
        RadioButton[,] my_chkbx_Setting_Type;
        ComboBox[] my_cmbbx_Standards;
        PictureBox[] my_picbx_Costom_Select;

        string[] dgv_col_name = new string[] { "time", "unit1_1", "unit1_2", "unit1_3", "unit1_4", "unit2_1", "unit2_2", "unit2_3", "unit2_4", "unit3_1", "unit3_2", "unit3_3", "unit3_4", "unit4_1", "unit4_2", "unit4_3", "unit4_4" };

        //Globally Unique Identifier (GUID) for HID class devices.  Windows uses GUIDs to identify things.
        Guid InterfaceClassGuid = new Guid(0x4d1e55b2, 0xf16f, 0x11cf, 0x88, 0xcb, 0x00, 0x11, 0x11, 0x00, 0x00, 0x30); 
	    //--------------- End of Global Varibles ------------------

        //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------


        //Need to check "Allow unsafe code" checkbox in build properties to use unsafe keyword.  Unsafe is needed to
        //properly interact with the unmanged C++ style APIs used to find and connect with the USB device.
        public unsafe Form1()
        {
            InitializeComponent();

            if (__DEBUG_FLAG__ == false)
            {
                this.Size = new System.Drawing.Size(1024, 571);
                //this.Size = new System.Drawing.Size(995, 519);
            }


            my_rbn_loop_type = new RadioButton[] { rbtn_one, rbtn_loop };
            my_chkbx_Setting_Type = new RadioButton[,] { { rbtn_standard_unit1, rbtn_custom_unit1 }, { rbtn_standard_unit2, rbtn_custom_unit2 }, { rbtn_standard_unit3, rbtn_custom_unit3 }, { rbtn_standard_unit4, rbtn_custom_unit4 } };
            my_cmbbx_Standards = new ComboBox[] { cmbbx_standard_unit1, cmbbx_standard_unit2, cmbbx_standard_unit3, cmbbx_standard_unit4 };
            my_picbx_Costom_Select = new PictureBox[] { picbx_Custom1, picbx_Custom2, picbx_Custom3, picbx_Custom4 };

            // ������
            btn_Set.Text = C_EXE_STRING;
            app_setting_data = new ST_APP_SETTING_DATA();
            app_setting_data.init(c_NIXIE_MAX_UNIT_NUM, c_NIXIE_TUBE_NUM);


            // �W���ݒ�̑I�����ݒ�
            for (int fi = 0; fi < my_cmbbx_Standards.Length; fi++)
            {
                for(int fj = 0; fj < Standard_Setting_Item_Name.Length;fj++)
                {
                    my_cmbbx_Standards[fi].Items.Add(Standard_Setting_Item_Name[fj]);
                }
                my_cmbbx_Standards[fi].SelectedIndex = 0;
            }
            // �J��Ԃ��ݒ� 1��
            rbtn_one.Checked = true;

            // �A�v���P�[�V�����f�[�^�ǂݍ���
            //app_setting_data = new ST_APP_SETTING_DATA();
            //app_setting_data.init(c_NIXIE_MAX_UNIT_NUM, c_NIXIE_TUBE_NUM);
            my_Read_App_Setting_Data(out app_setting_data);
            my_Set_Disp_App_Setting_Data(app_setting_data);




            // DEBUG
            my_Set_Numbers = new TextBox[] { txtbox_Num1, txtbox_Num2, txtbox_Num3, txtbox_Num4 };
            cmbbox_Unit.SelectedIndex = 0;

            // DEBUG

            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
			//Additional constructor code

            //Initialize tool tips, to provide pop up help when the mouse cursor is moved over objects on the form.
            //Register for WM_DEVICECHANGE notifications.  This code uses these messages to detect plug and play connection/disconnection events for USB devices
            DEV_BROADCAST_DEVICEINTERFACE DeviceBroadcastHeader = new DEV_BROADCAST_DEVICEINTERFACE();
            DeviceBroadcastHeader.dbcc_devicetype = DBT_DEVTYP_DEVICEINTERFACE;
            DeviceBroadcastHeader.dbcc_size = (uint)Marshal.SizeOf(DeviceBroadcastHeader);
            DeviceBroadcastHeader.dbcc_reserved = 0;	//Reserved says not to use...
            DeviceBroadcastHeader.dbcc_classguid = InterfaceClassGuid;

            //Need to get the address of the DeviceBroadcastHeader to call RegisterDeviceNotification(), but
            //can't use "&DeviceBroadcastHeader".  Instead, using a roundabout means to get the address by 
            //making a duplicate copy using Marshal.StructureToPtr().
            IntPtr pDeviceBroadcastHeader = IntPtr.Zero;  //Make a pointer.
            pDeviceBroadcastHeader = Marshal.AllocHGlobal(Marshal.SizeOf(DeviceBroadcastHeader)); //allocate memory for a new DEV_BROADCAST_DEVICEINTERFACE structure, and return the address 
            Marshal.StructureToPtr(DeviceBroadcastHeader, pDeviceBroadcastHeader, false);  //Copies the DeviceBroadcastHeader structure into the memory already allocated at DeviceBroadcastHeaderWithPointer
            RegisterDeviceNotification(this.Handle, pDeviceBroadcastHeader, DEVICE_NOTIFY_WINDOW_HANDLE);

			//Now make an initial attempt to find the USB device, if it was already connected to the PC and enumerated prior to launching the application.
			//If it is connected and present, we should open read and write handles to the device so we can communicate with it later.
			//If it was not connected, we will have to wait until the user plugs the device in, and the WM_DEVICECHANGE callback function can process
			//the message and again search for the device.
			if(CheckIfPresentAndGetUSBDevicePath())	//Check and make sure at least one device with matching VID/PID is attached
			{
				uint ErrorStatusWrite;
				uint ErrorStatusRead;


				//We now have the proper device path, and we can finally open read and write handles to the device.
                WriteHandleToUSBDevice = CreateFile(DevicePath, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                ErrorStatusWrite = (uint)Marshal.GetLastWin32Error();
                ReadHandleToUSBDevice = CreateFile(DevicePath, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                ErrorStatusRead = (uint)Marshal.GetLastWin32Error();

				if((ErrorStatusWrite == ERROR_SUCCESS) && (ErrorStatusRead == ERROR_SUCCESS))
				{
					AttachedState = true;		//Let the rest of the PC application know the USB device is connected, and it is safe to read/write to it
					AttachedButBroken = false;
                    connect_status_lbl.Text = "�ڑ�����܂���";
				}
				else //for some reason the device was physically plugged in, but one or both of the read/write handles didn't open successfully...
				{
					AttachedState = false;		//Let the rest of this application known not to read/write to the device.
					AttachedButBroken = true;	//Flag so that next time a WM_DEVICECHANGE message occurs, can retry to re-open read/write pipes
					if(ErrorStatusWrite == ERROR_SUCCESS)
						WriteHandleToUSBDevice.Close();
					if(ErrorStatusRead == ERROR_SUCCESS)
						ReadHandleToUSBDevice.Close();
				}
			}
			else	//Device must not be connected (or not programmed with correct firmware)
			{
				AttachedState = false;
				AttachedButBroken = false;
			}

            if (AttachedState == true)
            {
                connect_status_lbl.Text = "�ڑ�����܂����B";
            }
            else
            {
                connect_status_lbl.Text = "�ڑ�����Ă��܂���B";
            }

			ReadWriteThread.RunWorkerAsync();	//Recommend performing USB read/write operations in a separate thread.  Otherwise,
												//the Read/Write operations are effectively blocking functions and can lock up the
												//user interface if the I/O operations take a long time to complete.

            //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                my_Save_App_Setting_Data(app_setting_data);
            }
            catch
            {
            }
        }

        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------

        //FUNCTION:	CheckIfPresentAndGetUSBDevicePath()
        //PURPOSE:	Check if a USB device is currently plugged in with a matching VID and PID
        //INPUT:	Uses globally declared String DevicePath, globally declared GUID, and the MY_DEVICE_ID constant.
        //OUTPUT:	Returns BOOL.  TRUE when device with matching VID/PID found.  FALSE if device with VID/PID could not be found.
        //			When returns TRUE, the globally accessable "DetailedInterfaceDataStructure" will contain the device path
        //			to the USB device with the matching VID/PID.

        bool CheckIfPresentAndGetUSBDevicePath()
        {
		    /* 
		    Before we can "connect" our application to our USB embedded device, we must first find the device.
		    A USB bus can have many devices simultaneously connected, so somehow we have to find our device only.
		    This is done with the Vendor ID (VID) and Product ID (PID).  Each USB product line should have
		    a unique combination of VID and PID.  

		    Microsoft has created a number of functions which are useful for finding plug and play devices.  Documentation
		    for each function used can be found in the MSDN library.  We will be using the following functions (unmanaged C functions):

		    SetupDiGetClassDevs()					//provided by setupapi.dll, which comes with Windows
		    SetupDiEnumDeviceInterfaces()			//provided by setupapi.dll, which comes with Windows
		    GetLastError()							//provided by kernel32.dll, which comes with Windows
		    SetupDiDestroyDeviceInfoList()			//provided by setupapi.dll, which comes with Windows
		    SetupDiGetDeviceInterfaceDetail()		//provided by setupapi.dll, which comes with Windows
		    SetupDiGetDeviceRegistryProperty()		//provided by setupapi.dll, which comes with Windows
		    CreateFile()							//provided by kernel32.dll, which comes with Windows

            In order to call these unmanaged functions, the Marshal class is very useful.
             
		    We will also be using the following unusual data types and structures.  Documentation can also be found in
		    the MSDN library:

		    PSP_DEVICE_INTERFACE_DATA
		    PSP_DEVICE_INTERFACE_DETAIL_DATA
		    SP_DEVINFO_DATA
		    HDEVINFO
		    HANDLE
		    GUID

		    The ultimate objective of the following code is to get the device path, which will be used elsewhere for getting
		    read and write handles to the USB device.  Once the read/write handles are opened, only then can this
		    PC application begin reading/writing to the USB device using the WriteFile() and ReadFile() functions.

		    Getting the device path is a multi-step round about process, which requires calling several of the
		    SetupDixxx() functions provided by setupapi.dll.
		    */

            try
            {
		        IntPtr DeviceInfoTable = IntPtr.Zero;
		        SP_DEVICE_INTERFACE_DATA InterfaceDataStructure = new SP_DEVICE_INTERFACE_DATA();
                SP_DEVICE_INTERFACE_DETAIL_DATA DetailedInterfaceDataStructure = new SP_DEVICE_INTERFACE_DETAIL_DATA();
                SP_DEVINFO_DATA DevInfoData = new SP_DEVINFO_DATA();

		        uint InterfaceIndex = 0;
		        uint dwRegType = 0;
		        uint dwRegSize = 0;
                uint dwRegSize2 = 0;
		        uint StructureSize = 0;
		        IntPtr PropertyValueBuffer = IntPtr.Zero;
		        bool MatchFound = false;
		        uint ErrorStatus;
		        uint LoopCounter = 0;

                //Use the formatting: "Vid_xxxx&Pid_xxxx" where xxxx is a 16-bit hexadecimal number.
                //Make sure the value appearing in the parathesis matches the USB device descriptor
                //of the device that this aplication is intending to find.
                String DeviceIDToFind = DEF_VID_PID;

		        //First populate a list of plugged in devices (by specifying "DIGCF_PRESENT"), which are of the specified class GUID. 
		        DeviceInfoTable = SetupDiGetClassDevs(ref InterfaceClassGuid, IntPtr.Zero, IntPtr.Zero, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);

                if(DeviceInfoTable != IntPtr.Zero)
                {
		            //Now look through the list we just populated.  We are trying to see if any of them match our device. 
		            while(true)
		            {
                        InterfaceDataStructure.cbSize = (uint)Marshal.SizeOf(InterfaceDataStructure);
			            if(SetupDiEnumDeviceInterfaces(DeviceInfoTable, IntPtr.Zero, ref InterfaceClassGuid, InterfaceIndex, ref InterfaceDataStructure))
			            {
                            ErrorStatus = (uint)Marshal.GetLastWin32Error();
                            if (ErrorStatus == ERROR_NO_MORE_ITEMS)	//Did we reach the end of the list of matching devices in the DeviceInfoTable?
				            {	//Cound not find the device.  Must not have been attached.
					            SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
					            return false;		
				            }
			            }
			            else	//Else some other kind of unknown error ocurred...
			            {
                            ErrorStatus = (uint)Marshal.GetLastWin32Error();
				            SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
				            return false;	
			            }

			            //Now retrieve the hardware ID from the registry.  The hardware ID contains the VID and PID, which we will then 
			            //check to see if it is the correct device or not.

			            //Initialize an appropriate SP_DEVINFO_DATA structure.  We need this structure for SetupDiGetDeviceRegistryProperty().
                        DevInfoData.cbSize = (uint)Marshal.SizeOf(DevInfoData);
			            SetupDiEnumDeviceInfo(DeviceInfoTable, InterfaceIndex, ref DevInfoData);

			            //First query for the size of the hardware ID, so we can know how big a buffer to allocate for the data.
			            SetupDiGetDeviceRegistryProperty(DeviceInfoTable, ref DevInfoData, SPDRP_HARDWAREID, ref dwRegType, IntPtr.Zero, 0, ref dwRegSize);

			            //Allocate a buffer for the hardware ID.
                        //Should normally work, but could throw exception "OutOfMemoryException" if not enough resources available.
                        PropertyValueBuffer = Marshal.AllocHGlobal((int)dwRegSize);

			            //Retrieve the hardware IDs for the current device we are looking at.  PropertyValueBuffer gets filled with a 
			            //REG_MULTI_SZ (array of null terminated strings).  To find a device, we only care about the very first string in the
			            //buffer, which will be the "device ID".  The device ID is a string which contains the VID and PID, in the example 
			            //format "Vid_04d8&Pid_003f".
                        SetupDiGetDeviceRegistryProperty(DeviceInfoTable, ref DevInfoData, SPDRP_HARDWAREID, ref dwRegType, PropertyValueBuffer, dwRegSize, ref dwRegSize2);

			            //Now check if the first string in the hardware ID matches the device ID of the USB device we are trying to find.
			            String DeviceIDFromRegistry = Marshal.PtrToStringUni(PropertyValueBuffer); //Make a new string, fill it with the contents from the PropertyValueBuffer

			            Marshal.FreeHGlobal(PropertyValueBuffer);		//No longer need the PropertyValueBuffer, free the memory to prevent potential memory leaks

			            //Convert both strings to lower case.  This makes the code more robust/portable accross OS Versions
			            DeviceIDFromRegistry = DeviceIDFromRegistry.ToLowerInvariant();	
			            DeviceIDToFind = DeviceIDToFind.ToLowerInvariant();				
			            //Now check if the hardware ID we are looking at contains the correct VID/PID
			            MatchFound = DeviceIDFromRegistry.Contains(DeviceIDToFind);		
			            if(MatchFound == true)
			            {
                            //Device must have been found.  In order to open I/O file handle(s), we will need the actual device path first.
				            //We can get the path by calling SetupDiGetDeviceInterfaceDetail(), however, we have to call this function twice:  The first
				            //time to get the size of the required structure/buffer to hold the detailed interface data, then a second time to actually 
				            //get the structure (after we have allocated enough memory for the structure.)
                            DetailedInterfaceDataStructure.cbSize = (uint)Marshal.SizeOf(DetailedInterfaceDataStructure);
				            //First call populates "StructureSize" with the correct value
				            SetupDiGetDeviceInterfaceDetail(DeviceInfoTable, ref InterfaceDataStructure, IntPtr.Zero, 0, ref StructureSize, IntPtr.Zero);
                            //Need to call SetupDiGetDeviceInterfaceDetail() again, this time specifying a pointer to a SP_DEVICE_INTERFACE_DETAIL_DATA buffer with the correct size of RAM allocated.
                            //First need to allocate the unmanaged buffer and get a pointer to it.
                            IntPtr pUnmanagedDetailedInterfaceDataStructure = IntPtr.Zero;  //Declare a pointer.
                            pUnmanagedDetailedInterfaceDataStructure = Marshal.AllocHGlobal((int)StructureSize);    //Reserve some unmanaged memory for the structure.
                            DetailedInterfaceDataStructure.cbSize = 6; //Initialize the cbSize parameter (4 bytes for DWORD + 2 bytes for unicode null terminator)
                            Marshal.StructureToPtr(DetailedInterfaceDataStructure, pUnmanagedDetailedInterfaceDataStructure, false); //Copy managed structure contents into the unmanaged memory buffer.

                            //Now call SetupDiGetDeviceInterfaceDetail() a second time to receive the device path in the structure at pUnmanagedDetailedInterfaceDataStructure.
                            if (SetupDiGetDeviceInterfaceDetail(DeviceInfoTable, ref InterfaceDataStructure, pUnmanagedDetailedInterfaceDataStructure, StructureSize, IntPtr.Zero, IntPtr.Zero))
                            {
                                //Need to extract the path information from the unmanaged "structure".  The path starts at (pUnmanagedDetailedInterfaceDataStructure + sizeof(DWORD)).
                                IntPtr pToDevicePath = new IntPtr((uint)pUnmanagedDetailedInterfaceDataStructure.ToInt32() + 4);  //Add 4 to the pointer (to get the pointer to point to the path, instead of the DWORD cbSize parameter)
                                DevicePath = Marshal.PtrToStringUni(pToDevicePath); //Now copy the path information into the globally defined DevicePath String.
                                
                                //We now have the proper device path, and we can finally use the path to open I/O handle(s) to the device.
                                SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
                                Marshal.FreeHGlobal(pUnmanagedDetailedInterfaceDataStructure);  //No longer need this unmanaged SP_DEVICE_INTERFACE_DETAIL_DATA buffer.  We already extracted the path information.
                                return true;    //Returning the device path in the global DevicePath String
                            }
                            else //Some unknown failure occurred
                            {
                                uint ErrorCode = (uint)Marshal.GetLastWin32Error();
                                SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure.
                                Marshal.FreeHGlobal(pUnmanagedDetailedInterfaceDataStructure);  //No longer need this unmanaged SP_DEVICE_INTERFACE_DETAIL_DATA buffer.  We already extracted the path information.
                                return false;    
                            }
                        }

			            InterfaceIndex++;	
			            //Keep looping until we either find a device with matching VID and PID, or until we run out of devices to check.
			            //However, just in case some unexpected error occurs, keep track of the number of loops executed.
			            //If the number of loops exceeds a very large number, exit anyway, to prevent inadvertent infinite looping.
			            LoopCounter++;
			            if(LoopCounter == 10000000)	//Surely there aren't more than 10 million devices attached to any forseeable PC...
			            {
				            return false;
			            }
		            }//end of while(true)
                }
                return false;
            }//end of try
            catch
            {
                //Something went wrong if PC gets here.  Maybe a Marshal.AllocHGlobal() failed due to insufficient resources or something.
			    return false;	
            }
        }
        //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------


        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
        //This is a callback function that gets called when a Windows message is received by the form.
        //We will receive various different types of messages, but the ones we really want to use are the WM_DEVICECHANGE messages.
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_DEVICECHANGE)
            {
                if (((int)m.WParam == DBT_DEVICEARRIVAL) || ((int)m.WParam == DBT_DEVICEREMOVEPENDING) || ((int)m.WParam == DBT_DEVICEREMOVECOMPLETE) || ((int)m.WParam == DBT_CONFIGCHANGED))
                {
                    //WM_DEVICECHANGE messages by themselves are quite generic, and can be caused by a number of different
                    //sources, not just your USB hardware device.  Therefore, must check to find out if any changes relavant
                    //to your device (with known VID/PID) took place before doing any kind of opening or closing of handles/endpoints.
                    //(the message could have been totally unrelated to your application/USB device)

                    if (CheckIfPresentAndGetUSBDevicePath())	//Check and make sure at least one device with matching VID/PID is attached
                    {
                        //If executes to here, this means the device is currently attached and was found.
                        //This code needs to decide however what to do, based on whether or not the device was previously known to be
                        //attached or not.
                        if ((AttachedState == false) || (AttachedButBroken == true))	//Check the previous attachment state
                        {
                            uint ErrorStatusWrite;
                            uint ErrorStatusRead;

                            //We obtained the proper device path (from CheckIfPresentAndGetUSBDevicePath() function call), and it
                            //is now possible to open read and write handles to the device.
                            WriteHandleToUSBDevice = CreateFile(DevicePath, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                            ErrorStatusWrite = (uint)Marshal.GetLastWin32Error();
                            ReadHandleToUSBDevice = CreateFile(DevicePath, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                            ErrorStatusRead = (uint)Marshal.GetLastWin32Error();

                            if ((ErrorStatusWrite == ERROR_SUCCESS) && (ErrorStatusRead == ERROR_SUCCESS))
                            {
                                AttachedState = true;		//Let the rest of the PC application know the USB device is connected, and it is safe to read/write to it
                                AttachedButBroken = false;
                                connect_status_lbl.Text = "�ڑ�����܂����B";

                            }
                            else //for some reason the device was physically plugged in, but one or both of the read/write handles didn't open successfully...
                            {
                                AttachedState = false;		//Let the rest of this application known not to read/write to the device.
                                AttachedButBroken = true;	//Flag so that next time a WM_DEVICECHANGE message occurs, can retry to re-open read/write pipes
                                if (ErrorStatusWrite == ERROR_SUCCESS)
                                    WriteHandleToUSBDevice.Close();
                                if (ErrorStatusRead == ERROR_SUCCESS)
                                    ReadHandleToUSBDevice.Close();
                            }
                        }
                        //else we did find the device, but AttachedState was already true.  In this case, don't do anything to the read/write handles,
                        //since the WM_DEVICECHANGE message presumably wasn't caused by our USB device.  
                    }
                    else	//Device must not be connected (or not programmed with correct firmware)
                    {
                        if (AttachedState == true)		//If it is currently set to true, that means the device was just now disconnected
                        {
                            AttachedState = false;
                            WriteHandleToUSBDevice.Close();
                            ReadHandleToUSBDevice.Close();
                        }
                        AttachedState = false;
                        AttachedButBroken = false;
                    }
                }
            } //end of: if(m.Msg == WM_DEVICECHANGE)

            base.WndProc(ref m);
        } //end of: WndProc() function
        //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------


        private void ReadWriteThread_DoWork(object sender, DoWorkEventArgs e)
        {
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------

            /*This thread does the actual USB read/write operations (but only when AttachedState == true) to the USB device.
            It is generally preferrable to write applications so that read and write operations are handled in a separate
            thread from the main form.  This makes it so that the main form can remain responsive, even if the I/O operations
            take a very long time to complete.

            Since this is a separate thread, this code below executes independently from the rest of the
            code in this application.  All this thread does is read and write to the USB device.  It does not update
            the form directly with the new information it obtains (such as the ANxx/POT Voltage or pushbutton state).
            The information that this thread obtains is stored in atomic global variables.
            Form updates are handled by the FormUpdateTimer Tick event handler function.

            This application sends packets to the endpoint buffer on the USB device by using the "WriteFile()" function.
            This application receives packets from the endpoint buffer on the USB device by using the "ReadFile()" function.
            Both of these functions are documented in the MSDN library.  Calling ReadFile() is a not perfectly straight
            foward in C# environment, since one of the input parameters is a pointer to a buffer that gets filled by ReadFile().
            The ReadFile() function is therefore called through a wrapper function ReadFileManagedBuffer().

            All ReadFile() and WriteFile() operations in this example project are synchronous.  They are blocking function
            calls and only return when they are complete, or if they fail because of some event, such as the user unplugging
            the device.  It is possible to call these functions with "overlapped" structures, and use them as non-blocking
            asynchronous I/O function calls.  

            Note:  This code may perform differently on some machines when the USB device is plugged into the host through a
            USB 2.0 hub, as opposed to a direct connection to a root port on the PC.  In some cases the data rate may be slower
            when the device is connected through a USB 2.0 hub.  This performance difference is believed to be caused by
            the issue described in Microsoft knowledge base article 940021:
            http://support.microsoft.com/kb/940021/en-us 

            Higher effective bandwidth (up to the maximum offered by interrupt endpoints), both when connected
            directly and through a USB 2.0 hub, can generally be achieved by queuing up multiple pending read and/or
            write requests simultaneously.  This can be done when using	asynchronous I/O operations (calling ReadFile() and
            WriteFile()	with overlapped structures).  The Microchip	HID USB Bootloader application uses asynchronous I/O
            for some USB operations and the source code can be used	as an example.*/


            Byte[] OUTBuffer = new byte[65];	//Allocate a memory buffer equal to the OUT endpoint size + 1
		    Byte[] INBuffer = new byte[65];		//Allocate a memory buffer equal to the IN endpoint size + 1
		    uint BytesWritten = 0;
		    uint BytesRead = 0;

		    while(true)
		    {
                try
                {
                    if (AttachedState == true)	//Do not try to use the read/write handles unless the USB device is attached and ready
                    {
                        //VersionReadReq = false;
                        if (VersionReadReq == true)
                        {
                            VersionReadReq = false;

                            //Get the pushbutton state from the microcontroller firmware.
                            for (uint i = 0; i < OUTBuffer.Length; i++) { OUTBuffer[i] = 0xFF; }

                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x56;		//0x81 is the "Get Pushbutton State" command in the firmware

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x56)
                                        {
                                            for (uint i = 2; i < 65; i++)
                                            {
                                                version_buff[i - 2] = INBuffer[i];
                                            }
                                            VersionReadComp = true;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }
                        // Time Set
                        if (b_TimeSet_flag == true)
                        {
                            b_TimeSet_flag = false;

                            //Get the pushbutton state from the microcontroller firmware.
                            for (uint i = 0; i < OUTBuffer.Length; i++) { OUTBuffer[i] = 0xFF; }

                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x21;		//0x21 is the "Get Pushbutton State" command in the firmware

                            OUTBuffer[2] = (byte)(Time_Set_Num[0] & 0xFF);
                            OUTBuffer[3] = (byte)(Time_Set_Num[1] & 0xFF);
                            OUTBuffer[4] = (byte)(Time_Set_Num[2] & 0xFF);
                            OUTBuffer[5] = (byte)(Time_Set_Num[3] & 0xFF);
                            OUTBuffer[6] = (byte)(Time_Set_Num[4] & 0xFF);
                            OUTBuffer[7] = (byte)(Time_Set_Num[5] & 0xFF);
                            OUTBuffer[8] = (byte)(Time_Set_Num[6] & 0xFF);

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x21)
                                        {
                                            // Set Complete
                                            // 
                                        }
                                    }
                                }
                            }
                        }
                        // Set Number
                        if (b_NumberSet_flag == true)
                        {
                            b_NumberSet_flag = false;

                            //Get the pushbutton state from the microcontroller firmware.
                            for (uint i = 0; i < OUTBuffer.Length; i++) { OUTBuffer[i] = 0xFF; }

                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x22;		//0x21 is the "Get Pushbutton State" command in the firmware

                            if (1 <= Set_Nixie_Unit && Set_Nixie_Unit <= c_NIXIE_MAX_UNIT_NUM)
                            {
                                OUTBuffer[2] = Set_Nixie_Unit;
                                for (int fi = 0; fi < c_NIXIE_TUBE_NUM; fi++)
                                {
                                    OUTBuffer[3 + fi] = Set_Number[Set_Nixie_Unit-1, fi];
                                    OUTBuffer[3 + fi + c_NIXIE_TUBE_NUM] = Set_Control1[Set_Nixie_Unit-1, fi];
                                    OUTBuffer[3 + fi + c_NIXIE_TUBE_NUM * 2] = Set_Control2[Set_Nixie_Unit-1, fi];
                                }
                            }

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x22)
                                        {
                                            // Set Complete
                                            // 
                                        }
                                    }
                                }
                            }
                        }
                        // Set All Number
                        if (b_All_NumberSet_flag == true)
                        {
                            b_All_NumberSet_flag = false;

                            //Get the pushbutton state from the microcontroller firmware.
                            for (uint i = 0; i < OUTBuffer.Length; i++) { OUTBuffer[i] = 0xFF; }

                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x23;		//0x21 is the "Get Pushbutton State" command in the firmware

                            for (int fi = 0; fi < c_NIXIE_MAX_UNIT_NUM; fi++)
                            {
                                for (int fj = 0; fj < c_NIXIE_TUBE_NUM; fj++ )
                                {
                                    OUTBuffer[2 + fj + fi * 3 * c_NIXIE_TUBE_NUM] = Set_Number[fi, fj];
                                    OUTBuffer[2 + fj + c_NIXIE_TUBE_NUM + fi * 3 * c_NIXIE_TUBE_NUM] = Set_Control1[fi, fj];
                                    OUTBuffer[2 + fj + c_NIXIE_TUBE_NUM * 2 + fi * 3 * c_NIXIE_TUBE_NUM] = Set_Control2[fi, fj];
                                }
                            }

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x22)
                                        {
                                            // Set Complete
                                            //
                                        }
                                    }
                                }
                            }
                        }

                        // Get Number Request
                        if (b_NumberGet_req_flag == true)
                        {
                            b_NumberGet_req_flag = false;

                            //Get the pushbutton state from the microcontroller firmware.
                            for (uint i = 0; i < OUTBuffer.Length; i++) { OUTBuffer[i] = 0xFF; }

                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x24;		//0x21 is the "Get Pushbutton State" command in the firmware

                            OUTBuffer[2] = Get_Nixie_Unit;

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x24)
                                        {
                                            // Set Complete
                                            if (INBuffer[2] == 0x00)
                                            {
                                                b_NumberGet_read_flag = true;
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Get Number Read
                        if (b_NumberGet_read_flag == true)
                        {

                            //Get the pushbutton state from the microcontroller firmware.
                            for (uint i = 0; i < 65; i++) { OUTBuffer[i] = 0xFF; }

                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x25;		//0x21 is the "Get Pushbutton State" command in the firmware

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x25)
                                        {
                                            //
                                            if (INBuffer[2] != 0x00)
                                            {   // �ǂݍ��݊���
                                                for (int fi = 0; fi < c_NIXIE_TUBE_NUM; fi++)
                                                {
                                                    Get_Number[fi] = INBuffer[3+fi];
                                                    Get_Control1[fi] = INBuffer[3 + fi + c_NIXIE_TUBE_NUM];
                                                    Get_Control2[fi] = INBuffer[3 + fi + c_NIXIE_TUBE_NUM*2];
                                                }

                                                b_NumberGet_read_flag = false;
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Set Blink Interval
                        if (b_Blink_Interval_Set_flag == true)
                        {
                            b_Blink_Interval_Set_flag = false;

                            //Get the pushbutton state from the microcontroller firmware.
                            for (uint i = 0; i < OUTBuffer.Length; i++) { OUTBuffer[i] = 0xFF; }

                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x26;		//0x21 is the "Get Pushbutton State" command in the firmware

                            OUTBuffer[2] = 1;
                            uint ui_tmp = 1000;
                            OUTBuffer[3] = (byte)(ui_tmp & 0xFF);
                            OUTBuffer[4] = (byte)((ui_tmp >> 8) & 0xFF);
                            ui_tmp = 1000;
                            OUTBuffer[5] = (byte)(ui_tmp & 0xFF);
                            OUTBuffer[6] = (byte)((ui_tmp >> 8) & 0xFF);

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x26)
                                        {
                                            // Set Complete
                                            // 
                                        }
                                    }
                                }
                            }
                        }

                        //DEBUG DEBUG DEBUG *****************************************************************************************************
                        //Get the pushbutton state from the microcontroller firmware.
                        OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                        OUTBuffer[1] = 0x40;		//0x81 is the "Get Pushbutton State" command in the firmware
                        for (uint i = 2; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.

                        //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                        if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                        {
                            //Now get the response packet from the firmware.
                            INBuffer[0] = 0;
                            {
                                if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                {
                                    //INBuffer[0] is the report ID, which we don't care about.
                                    //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                    //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                    if (INBuffer[1] == 0x40)
                                    {
                                        // DEBUG
                                        for (int fi = 0; fi < Debug_Array.Length; fi++)
                                        {
                                            Debug_Array[fi] = (int)(INBuffer[fi+2]);
                                        }
                                    }
                                }
                            }
                        }
                        //Get the pushbutton state from the microcontroller firmware.
                        OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                        OUTBuffer[1] = 0x41;		//0x81 is the "Get Pushbutton State" command in the firmware
                        for (uint i = 2; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.

                        //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                        if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                        {
                            //Now get the response packet from the firmware.
                            INBuffer[0] = 0;
                            {
                                if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                {
                                    //INBuffer[0] is the report ID, which we don't care about.
                                    //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                    //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                    if (INBuffer[1] == 0x41)
                                    {
                                        // DEBUG
                                        for (int fi = 0; fi < Debug_Arr2.Length; fi++)
                                        {
                                            Debug_Arr2[fi] = (int)(INBuffer[fi + 2]);
                                        }
                                    }
                                }
                            }
                        }
                        //DEBUG DEBUG DEBUG *****************************************************************************************************
                    } //end of: if(AttachedState == true)
                    else
                    {
                        Thread.Sleep(5);	//Add a small delay.  Otherwise, this while(true) loop can execute very fast and cause 
                                            //high CPU utilization, with no particular benefit to the application.
                    }
                }
                catch
                {
                    //Exceptions can occur during the read or write operations.  For example,
                    //exceptions may occur if for instance the USB device is physically unplugged
                    //from the host while the above read/write functions are executing.

                    //Don't need to do anything special in this case.  The application will automatically
                    //re-establish communications based on the global AttachedState boolean variable used
                    //in conjunction with the WM_DEVICECHANGE messages to dyanmically respond to Plug and Play
                    //USB connection events.
                }

		    } //end of while(true) loop
            //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        }



        private void FormUpdateTimer_Tick(object sender, EventArgs e)
        {
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
            //This timer tick event handler function is used to update the user interface on the form, based on data
            //obtained asynchronously by the ReadWriteThread and the WM_DEVICECHANGE event handler functions.

            //Check if user interface on the form should be enabled or not, based on the attachment state of the USB device.
            if (AttachedState == true)
            {
                //Device is connected and ready to communicate, enable user interface on the form 
                StatusBox_lbl.Text = "�f�o�C�X���o��";
                connect_status_lbl.Text = "�ڑ�����܂����B";

                // �R���g���[����L����
                btn_Set.Enabled = true;
                lbl_Set_Date.Enabled = true;


                if (AttachedFirstTime == true)
                {   // �N����A����ڑ�
                    AttachedFirstTime = false;

                }
                if (Now_Background_image != 1)
                {   // �ڑ����̃C���[�W�ɕύX
                    Now_Background_image = 1;
                    this.BackgroundImage = global::NixieKit.Properties.Resources.BG_ON;

                    Status_C_pb.Visible = true;
                    Status_NC_pb.Visible = false;
                }

                if (VersionReadComp == true)
                {   // �o�[�W�����ǂݍ��݊���
                    VersionReadComp = false;

                    lbl_FW_Version.Enabled = true;
                    lbl_FW_Version.Text = c_VERSION + Encoding.Default.GetString(version_buff);
                }


                // �J�X�^���f�[�^�̑��M
                // �\���f�[�^���M
                if (b_exe_flag == false)
                {   // �����s�̂��ߎ��s�\��
                    btn_Set.Text = C_EXE_STRING;
                    gbx_Custom_Setting.Enabled = true;
                }
                else
                {   // ���s���̂��ߒ�~�\��
                    btn_Set.Text = C_NON_EXE_STRING;
                    gbx_Custom_Setting.Enabled = false;

                    if ((DateTime.Now - app_setting_data.dt_next_exe_time).TotalMilliseconds >= 0)
                    {   // ���̕\���f�[�^���M

                        // �W���f�[�^�Z�b�g
                        for (int unit_no = 0; unit_no < c_NIXIE_MAX_UNIT_NUM; unit_no++)
                        {
                            if (app_setting_data.setting_type[unit_no] == c_SETTING_TYPE_ID_STANDARD)
                            {
                                for (int nixie_no = 0; nixie_no < c_NIXIE_TUBE_NUM; nixie_no++)
                                {
                                    Set_Number[unit_no, nixie_no] = app_setting_data.standard_setting_number[unit_no, nixie_no];
                                    Set_Control1[unit_no, nixie_no] = app_setting_data.standard_setting_control1[unit_no, nixie_no];
                                    Set_Control2[unit_no, nixie_no] = app_setting_data.standard_setting_control2[unit_no, nixie_no];
                                }
                            }
                            else
                            {
                                for (int nixie_no = 0; nixie_no < c_NIXIE_TUBE_NUM; nixie_no++)
                                {
                                    Set_Number[unit_no, nixie_no] = 0xFF;
                                    Set_Control1[unit_no, nixie_no] = 0;
                                    Set_Control2[unit_no, nixie_no] = 0;
                                }
                            }
                        }


                        // �J�X�^���f�[�^�Z�b�g
                        if (list_Custom_Data.Count > 0)
                        {
                            byte tmp_number = 0;
                            byte tmp_control = 0;
                            for (int unit_no = 0; unit_no < c_NIXIE_MAX_UNIT_NUM; unit_no++)
                            {
                                if (app_setting_data.setting_type[unit_no] == c_SETTING_TYPE_ID_CUSTOM)
                                {
                                    for (int nixie_no = 0; nixie_no < c_NIXIE_TUBE_NUM; nixie_no++)
                                    {
                                        if (my_Get_Set_Number_Data(list_Custom_Data[app_setting_data.exe_idx].custom_data[unit_no, nixie_no], ref tmp_number, ref tmp_control) == 0)
                                        {
                                            Set_Number[unit_no, nixie_no] = tmp_number;
                                            Set_Control1[unit_no, nixie_no] = tmp_control;
                                            Set_Control2[unit_no, nixie_no] = 0;
                                        }
                                        else
                                        {   // �G���[
                                            Set_Number[unit_no, nixie_no] = 0xFF;
                                            Set_Control1[unit_no, nixie_no] = 0;
                                            Set_Control2[unit_no, nixie_no] = 0;
                                        }
                                    }
                                }
                            }

                            // ���̎��s���ԃZ�b�g
                            app_setting_data.dt_next_exe_time = app_setting_data.dt_next_exe_time.AddMilliseconds(list_Custom_Data[app_setting_data.exe_idx].time);
                        }

                        // ���̑��M�f�[�^��
                        app_setting_data.exe_idx++;
                        if (list_Custom_Data.Count == 0)
                        {   // �J�X�^���ݒ�Ȃ�
                            // �I��
                            app_setting_data.exe_idx = 0;
                            b_exe_flag = false;
                        }
                        else if (app_setting_data.exe_idx >= list_Custom_Data.Count)
                        {   // �S�ẴJ�X�^���f�[�^���M����

                            // ���M�f�[�^��擪��
                            app_setting_data.exe_idx = 0;

                            // �J��Ԃ��^�C�v�́H
                            if (app_setting_data.loop_type != c_LOOP_TYPE_ID_LOOP)
                            {   // ���[�v�ȊO�̎��͏I��
                                b_exe_flag = false;
                            }
                        }

                        // ���M�t���O�Z�b�g
                        b_All_NumberSet_flag = true;
                    }
                }
            }
            if ((AttachedState == false) || (AttachedButBroken == true))
            {
                //Device not available to communicate. Disable user interface on the form.
                StatusBox_lbl.Text = "�f�o�C�X�����o";
                connect_status_lbl.Text = "�ڑ�����Ă��܂���B";

                if (Now_Background_image != 0)
                {   // ���ڑ��̃C���[�W�ɕύX
                    Now_Background_image = 0;
                    this.BackgroundImage = global::NixieKit.Properties.Resources.BG_OFF;

                    Status_NC_pb.Visible = true;
                    Status_C_pb.Visible = false;
                }

                // �R���g���[��������
                btn_Set.Enabled = false;
                lbl_Set_Date.Enabled = false;

                // ������
                lbl_FW_Version.Text = c_VERSION;
                lbl_FW_Version.Enabled = false;
                VersionReadReq = true;
                VersionReadComp = false;
            }

            //Update the various status indicators on the form with the latest info obtained from the ReadWriteThread()
            if (AttachedState == true)
            {




                //DEBUG
                string debug_str = "";
                for (int fi = 0; fi < Debug_Array.Length; fi++)
                {
                    debug_str += string.Format("{0:000} : ", fi);
                }
                colum_lbl.Text = debug_str;

                debug_str = "";
                for (int fi = 0; fi < Debug_Array.Length; fi++)
                {
                    debug_str += string.Format("{0:000} : ", Debug_Array[fi]);
                }
                debug01_lbl.Text = debug_str;

                debug_str = "";
                for (int fi = 0; fi < Debug_Array.Length; fi++)
                {
                    debug_str += string.Format(" {0:X2} : ", Debug_Array[fi]);
                }
                debug02_lbl.Text = debug_str;

                debug_str = "";
                for (int fi = 0; fi < Debug_Arr2.Length; fi++)
                {
                    debug_str += string.Format(" {0:X2} : ", Debug_Arr2[fi]);
                }
                debug03_lbl.Text = debug_str;
            }
            //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        }


        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------

        //--------------------------------------------------------------------------------------------------------------------------
        //FUNCTION:	ReadFileManagedBuffer()
        //PURPOSE:	Wrapper function to call ReadFile()
        //
        //INPUT:	Uses managed versions of the same input parameters as ReadFile() uses.
        //
        //OUTPUT:	Returns boolean indicating if the function call was successful or not.
        //          Also returns data in the byte[] INBuffer, and the number of bytes read. 
        //
        //Notes:    Wrapper function used to call the ReadFile() function.  ReadFile() takes a pointer to an unmanaged buffer and deposits
        //          the bytes read into the buffer.  However, can't pass a pointer to a managed buffer directly to ReadFile().
        //          This ReadFileManagedBuffer() is a wrapper function to make it so application code can call ReadFile() easier
        //          by specifying a managed buffer.
        //--------------------------------------------------------------------------------------------------------------------------
        public unsafe bool ReadFileManagedBuffer(SafeFileHandle hFile, byte[] INBuffer, uint nNumberOfBytesToRead, ref uint lpNumberOfBytesRead, IntPtr lpOverlapped)
        {
            IntPtr pINBuffer = IntPtr.Zero;

            try
            {
                pINBuffer = Marshal.AllocHGlobal((int)nNumberOfBytesToRead);    //Allocate some unmanged RAM for the receive data buffer.

                if (ReadFile(hFile, pINBuffer, nNumberOfBytesToRead, ref lpNumberOfBytesRead, lpOverlapped))
                {
                    Marshal.Copy(pINBuffer, INBuffer, 0, (int)lpNumberOfBytesRead);    //Copy over the data from unmanged memory into the managed byte[] INBuffer
                    Marshal.FreeHGlobal(pINBuffer);
                    return true;
                }
                else
                {
                    Marshal.FreeHGlobal(pINBuffer);
                    return false;
                }

            }
            catch
            {
                if (pINBuffer != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(pINBuffer);
                }
                return false;
            }
        }


        // DEBUG
        private void btn_Set_Number_Click(object sender, EventArgs e)
        {
            bool error_flag = false;
            byte tmp_number = 0;
            byte tmp_control = 0;
            try
            {
                try
                {
                    // �ݒ�o�b�t�@������
                    Set_Nixie_Unit = 0;
                    for (int fi = 0; fi < c_NIXIE_MAX_UNIT_NUM; fi++)
                    {
                        for (int fj = 0; fj < c_NIXIE_TUBE_NUM; fj++)
                        {
                            Set_Number[fi,fj] = c_DISP_NUMBER_NONE;
                            Set_Control1[fi, fj] = 0;
                            Set_Control2[fi, fj] = 0;
                        }
                    }

                    if (0 <= cmbbox_Unit.SelectedIndex && cmbbox_Unit.SelectedIndex < c_NIXIE_MAX_UNIT_NUM)
                    {
                        Set_Nixie_Unit = (byte)((cmbbox_Unit.SelectedIndex + 1) & 0xFF);
                    }
                    else
                    {   // �I���j�L�V�[�ǃ��j�b�g�ԍ��G���[
                        error_flag = true;
                    }

                    if (error_flag == false)
                    {
                        for (int fi = 0; fi < my_Set_Numbers.Length; fi++ )
                        {
                            if (my_Get_Set_Number_Data(my_Set_Numbers[fi].Text, ref tmp_number, ref tmp_control) == 0)
                            {
                                Set_Number[Set_Nixie_Unit-1,fi] = tmp_number;
                                Set_Control1[Set_Nixie_Unit - 1, fi] = tmp_control;
                                Set_Control2[Set_Nixie_Unit - 1, fi] = 0;
                            }
                            else
                            {   // �G���[
                                error_flag = true;
                                break;
                            }
                        }
                    }

                }
                catch
                {
                    error_flag = true;
                }
                if (error_flag == false)
                {
                    b_NumberSet_flag = true;
                }
                else
                {
                    MessageBox.Show("�ݒ�l������������܂���B������x�ݒ�l���m�F���Ă��������B", c_APPLICATION_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                }
            }
            catch
            {
            }
        }
        // DEBUG

        /// <summary>
        /// �\���f�[�^�̃`�F�b�N�ƕ\�����鐔�l����уh�b�g�f�[�^�̎擾���s��
        /// </summary>
        /// <param name="p_str_data"></param>
        /// <param name="out_number"></param>
        /// <param name="out_control"></param>
        /// <returns></returns>
        private int my_Get_Set_Number_Data(string p_str_data, ref byte out_number, ref byte out_control)
        {
            bool error_flag = false;
            int i_ret = -1;
            bool number_set_flag = false;
            try
            {
                // �o�̓o�b�t�@������
                out_number = c_DISP_NUMBER_NONE;
                out_control = 0;

                if (0 < p_str_data.Length && p_str_data.Length <= 5)
                {
                    // ��U CHeck OK
                    i_ret = 0;
                    string get_char_string;
                    for (int fi = 0; fi < p_str_data.Length; fi++)
                    {
                        get_char_string = p_str_data.Substring(fi,1);
                        if (get_char_string == "r" || get_char_string == "R")
                        {   // �E�h�b�g
                            out_control |= 0x01;
                            if (get_char_string == "R")
                            {   // �E�h�b�g�_��
                                out_control |= 0x04;
                            }
                        }
                        else if (get_char_string == "l" || get_char_string == "L")
                        {   //���h�b�g
                            out_control |= 0x02;
                            if (get_char_string == "L")
                            {   // ���h�b�g�_��
                                out_control |= 0x08;
                            }
                        }
                        else if (get_char_string == "f" || get_char_string == "F")
                        {   // ���\���̏ꍇ
                            out_control |= 0x10;
                        }
                        else if (get_char_string == "b" || get_char_string == "B")
                        {   // �����_�ł̏ꍇ
                            out_control |= 0x20;
                        }
                        else
                        {   // ���l�H
                            try
                            {
                                if (number_set_flag == false)
                                {
                                    int tmp_num = Convert.ToInt32(get_char_string, 10);
                                    out_number = (byte)(tmp_num & 0xFF);
                                    number_set_flag = true;
                                }
                                else
                                {   // ���l�ݒ�ς�
                                    error_flag = true;
                                }
                            }
                            catch
                            {   // ���l�ɕϊ��ł��Ȃ�
                                error_flag = true;
                            }
                        }
                    }
                }
                else if (p_str_data.Length == 0)
                {   // �\���Ȃ�
                    i_ret = 0;
                }

                // �����ƃh�b�g�̕\���Ȃ�
                if (out_number == c_DISP_NUMBER_NONE && (out_control & 0x03) == 0)
                {   // ����
                    out_control |= 0x80;
                }


            }
            catch
            {
                error_flag = true;
            }

            if (error_flag == true)
            {   // �G���[
                i_ret = -1;
                // �o�̓o�b�t�@������
                out_number = c_DISP_NUMBER_NONE;
                out_control = 0;
            }
            return i_ret;
        }

        // DEBUG
        private void btn_Set_Number_All_Click(object sender, EventArgs e)
        {
            try
            {
                byte tmp_num = 1;
                // �ݒ�o�b�t�@������
                Set_Nixie_Unit = 0;
                for (int fi = 0; fi < c_NIXIE_MAX_UNIT_NUM; fi++)
                {
                    for (int fj = 0; fj < c_NIXIE_TUBE_NUM; fj++)
                    {
                        Set_Number[fi, fj] = tmp_num++;
                        Set_Control1[fi, fj] = 0;
                        Set_Control2[fi, fj] = 0;

                        if (tmp_num > 9)
                        {
                            tmp_num = 0;
                        }
                    }
                }

                b_All_NumberSet_flag = true;
            }
            catch
            {
            }
        }
        //DEBUG

        private void btn_Read_Number_Click(object sender, EventArgs e)
        {
            bool error_flag = false;
            //byte tmp_number = 0;
            //byte tmp_control = 0; ;
            try
            {
                try
                {
                    b_NumberGet_req_flag = false;
                    b_NumberGet_read_flag = false;

                    // �ݒ�o�b�t�@������
                    Set_Nixie_Unit = 0;
                    for (int fi = 0; fi < c_NIXIE_TUBE_NUM; fi++)
                    {
                        Get_Number[fi] = c_DISP_NUMBER_NONE;
                        Get_Control1[fi] = 0;
                        Get_Control2[fi] = 0;
                    }

                    if (0 <= cmbbox_Unit.SelectedIndex && cmbbox_Unit.SelectedIndex < c_NIXIE_MAX_UNIT_NUM)
                    {
                        Get_Nixie_Unit = (byte)((cmbbox_Unit.SelectedIndex + 1) & 0xFF);
                    }
                    else
                    {   // �I���j�L�V�[�ǃ��j�b�g�ԍ��G���[
                        error_flag = true;
                    }
                }
                catch
                {
                    error_flag = true;
                }
                if (error_flag == false)
                {
                    b_NumberGet_req_flag = true;
                }
                else
                {
                    MessageBox.Show("�ݒ�l������������܂���B������x�ݒ�l���m�F���Ă��������B", c_APPLICATION_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                }
            }
            catch
            {
            }
        }

        private void btn_Set_Click(object sender, EventArgs e)
        {
            try
            {
                // �ݒ�o�b�t�@������
                Set_Nixie_Unit = 0;
                for (int fi = 0; fi < c_NIXIE_MAX_UNIT_NUM; fi++)
                {
                    for (int fj = 0; fj < c_NIXIE_TUBE_NUM; fj++)
                    {
                        Set_Number[fi, fj] = c_DISP_NUMBER_NONE;
                        Set_Control1[fi, fj] = 0;
                        Set_Control2[fi, fj] = 0;
                    }
                }

                if (b_exe_flag == false)
                {   // �����s�̂��ߎ��s

                    // ��ʃf�[�^�擾
                    my_Get_Custom_Disp_Data(list_Custom_Data);

                    app_setting_data.dt_start_time = DateTime.Now;
                    app_setting_data.dt_next_exe_time = DateTime.Now;
                    app_setting_data.exe_idx = 0;

                    b_exe_flag = true;
                }
                else
                {   // ���s���̂��ߒ�~


                    b_exe_flag = false;
                }
            }
            catch
            {
            }
        }

        private void btn_Import_Click(object sender, EventArgs e)
        {
            try
            {
                if(openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    my_Import_File(openFileDialog1.FileName);
                }
            }
            catch
            {
            }
        }

        private void my_Import_File(string p_File_Name)
        {
            bool error_flag = false;
            try
            {
                if (File.Exists(p_File_Name) == true)
                {
                    StreamReader sr = null;
                    try
                    {
                        List<ST_DISP_CUSTOM_DATA> li_disp_data = new List<ST_DISP_CUSTOM_DATA>();
                        ST_DISP_CUSTOM_DATA disp_1data = new ST_DISP_CUSTOM_DATA();

                        sr = new StreamReader(p_File_Name);

                        string s_1line = "";
                        //�t�@�C������s���ǂݍ���
                        while (sr.Peek() > -1)
                        {
                            // 1�s�ǂݍ���
                            s_1line = sr.ReadLine();

                            // �ǂݍ��񂾂P�s���A������z��ɕϊ�
                            string[] tmp_st;
                            int tmp_int;
                            SubFunction.CsvToStringArray(s_1line, out tmp_st, out tmp_int);

                            // ������z��ɕϊ������f�[�^���\���̂ɃZ�b�g�����X�g��
                            disp_1data.init(c_CUSTOM_DATA_DEFAULT_TIME, c_NIXIE_MAX_UNIT_NUM, c_NIXIE_TUBE_NUM);
                            // �f�[�^����OK�H
                            if (disp_1data.data_num == tmp_int)
                            {   // �f�[�^��OK

                                try
                                {
                                    disp_1data.time = uint.Parse(tmp_st[0]);
                                    for (int unit_idx = 0; unit_idx < disp_1data.custom_data.GetLength(0); unit_idx++)
                                    {
                                        for (int nixie_idx = 0; nixie_idx < disp_1data.custom_data.GetLength(1); nixie_idx++)
                                        {
                                            disp_1data.custom_data[unit_idx, nixie_idx] = tmp_st[1 + unit_idx * disp_1data.custom_data.GetLength(0) + nixie_idx];
                                        }
                                    }

                                    li_disp_data.Add(disp_1data);
                                }
                                catch
                                {   // �ϊ��ŗ�O����??
                                    error_flag = true;
                                    break;
                                }
                            }
                            else
                            {   // �f�[�^���ُ�
                                error_flag = true;
                                break;
                            }

                        }

                        if (error_flag == false)
                        {   // �����܂Ő���
                            list_Custom_Data = li_disp_data;
                            my_Set_Custom_Disp_Data(li_disp_data);
                        }
                    }
                    catch
                    {
                    }
                    finally
                    {
                        if (sr != null)
                        {
                            sr.Close();
                            sr.Dispose();
                        }
                    }
                }
            }
            catch
            {
            }
        }

        private void btn_Export_Click(object sender, EventArgs e)
        {
            try
            {
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    StreamWriter sw = null;
                    try
                    {
                        sw = new StreamWriter(saveFileDialog1.FileName);

                        List<ST_DISP_CUSTOM_DATA> li_disp_data = new List<ST_DISP_CUSTOM_DATA>();
                        //ST_DISP_CUSTOM_DATA disp_data = new ST_DISP_CUSTOM_DATA();
                        //disp_data.init(c_CUSTOM_DATA_DEFAULT_TIME, c_NIXIE_MAX_UNIT_NUM, c_NIXIE_TUBE_NUM);
                        // ��ʃf�[�^�擾
                        my_Get_Custom_Disp_Data(li_disp_data);

                        // ��ʃf�[�^�̍s�������[�v
                        for (int fi = 0; fi < li_disp_data.Count; fi++)
                        {
                            // 1�s���𕶎���z��ɕϊ� 
                            string[] line_data = new string[li_disp_data[fi].data_num];
                            line_data[0] = (li_disp_data[fi].time / c_CUSTOM_DATA_DEFAULT_TIME).ToString();
                            for (int unit_idx = 0; unit_idx < li_disp_data[fi].custom_data.GetLength(0); unit_idx++)
                            {
                                for (int nixie_idx = 0; nixie_idx < li_disp_data[fi].custom_data.GetLength(1); nixie_idx++)
                                {
                                    line_data[1 + unit_idx * li_disp_data[fi].custom_data.GetLength(0) + nixie_idx] = li_disp_data[fi].custom_data[unit_idx, nixie_idx];
                                }
                            }

                            // 1�s���̕�����z���csv������ɕϊ�
                            string csv_1line;
                            SubFunction.StringArrayToCsv(line_data, out csv_1line);

                            // �t�@�C���ɏ����o��
                            sw.WriteLine(csv_1line);
                        }

                    }
                    catch
                    {
                    }
                    finally
                    {
                        if (sw != null)
                        {
                            sw.Close();
                            sw.Dispose();
                        }
                    }
                }
            }
            catch
            {
            }
        }

        private void my_Set_Custom_Disp_Data(List<ST_DISP_CUSTOM_DATA> p_disp_custom_data)
        {
            try
            {
                dgv_DispSetData.Rows.Clear();

                int col_name_count = dgv_col_name.Length;
                int colCount = dgv_DispSetData.ColumnCount;

                int data_count = p_disp_custom_data.Count;
                for (int fi = 0; fi < data_count; fi++ )
                {

                    string[] row = new string[colCount];
                    for (int col_idx = 0; col_idx < colCount; col_idx++)
                    {
                        for (int col_name_idx = 0; col_name_idx < col_name_count; col_name_idx++)
                        {
                            if (dgv_DispSetData.Columns[col_idx].Name == dgv_col_name[0])
                            {
                                row[col_idx] = p_disp_custom_data[fi].time.ToString();
                                break;
                            }
                            else if (dgv_DispSetData.Columns[col_idx].Name == dgv_col_name[col_name_idx])
                            {
                                int unit_no =(col_name_idx-1) / c_NIXIE_MAX_UNIT_NUM;
                                int nixie_no =(col_name_idx-1) % c_NIXIE_TUBE_NUM;
                                row[col_idx] = p_disp_custom_data[fi].custom_data[unit_no, nixie_no];
                                break;
                            }
                        }
                    }

                    dgv_DispSetData.Rows.Insert(fi, row);
                }
            }
            catch
            {
            }
        }
        private void my_Get_Custom_Disp_Data(List<ST_DISP_CUSTOM_DATA> p_disp_custom_data)
        {
            ST_DISP_CUSTOM_DATA tmp_dcd = new ST_DISP_CUSTOM_DATA();
            int null_count;
            int blank_count;
            try
            {
                p_disp_custom_data.Clear();

                int col_name_count = dgv_col_name.Length;
                int colCount = dgv_DispSetData.ColumnCount;

                int data_count = dgv_DispSetData.RowCount;
                for (int fi = 0; fi < data_count;fi++ )
                {
                    null_count = 0;
                    blank_count = 0;
                    tmp_dcd.init(c_CUSTOM_DATA_DEFAULT_TIME, c_NIXIE_MAX_UNIT_NUM, c_NIXIE_TUBE_NUM);
                    for (int col_idx = 0; col_idx < colCount; col_idx++)
                    {
                        for (int col_name_idx = 0; col_name_idx < col_name_count; col_name_idx++)
                        {
                            if (dgv_DispSetData.Columns[col_idx].Name == dgv_col_name[0])
                            {
                                try
                                {
                                    if(dgv_DispSetData[col_idx, fi].Value == null)
                                    {
                                        null_count++;
                                    }
                                    else if (dgv_DispSetData[col_idx, fi].Value.ToString() == "")
                                    {
                                        blank_count++;
                                    }
                                    else
                                    {
                                        //tmp_dcd.time = uint.Parse(dgv_DispSetData[col_idx, fi].Value.ToString());
                                        tmp_dcd.time = uint.Parse(dgv_DispSetData[col_idx, fi].Value.ToString()) * C_INTERVAL_TIME_UNIT;
                                    }
                                }
                                catch
                                {
                                }
                                break;
                            }
                            else if (dgv_DispSetData.Columns[col_idx].Name == dgv_col_name[col_name_idx])
                            {
                                int unit_no = (col_name_idx - 1) / c_NIXIE_MAX_UNIT_NUM;
                                int nixie_no = (col_name_idx - 1) % c_NIXIE_TUBE_NUM;
                                try
                                {
                                    if (dgv_DispSetData[col_idx, fi].Value == null)
                                    {
                                        null_count++;
                                    }
                                    else if (dgv_DispSetData[col_idx, fi].Value.ToString() == "")
                                    {
                                        blank_count++;
                                    }
                                    else
                                    {
                                        tmp_dcd.custom_data[unit_no, nixie_no] = dgv_DispSetData[col_idx, fi].Value.ToString();
                                    }
                                }
                                catch
                                {
                                }
                                break;
                            }
                        }
                    }
                    if ((fi == (data_count - 1) && colCount == null_count) || colCount == (blank_count + null_count))
                    {   // �Ō�̃f�[�^�s�ŁA�f�[�^�S��null�̏ꍇ�͒ǉ����Ȃ� �܂��͋�
                    }
                    else
                    {
                        p_disp_custom_data.Add(tmp_dcd);
                    }
                }

            }
            catch
            {
            }
        }

        private void rbtn_Loop_Type_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (((RadioButton)sender).Checked == true)
                {
                    byte select_id = byte.Parse(((RadioButton)sender).Tag.ToString());
                    app_setting_data.loop_type = select_id;
                }
            }
            catch
            {
            }
        }

        private void rbtn_standard_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (((RadioButton)sender).Checked == true)
                {
                    byte select_id = byte.Parse(((RadioButton)sender).Tag.ToString());
                    app_setting_data.setting_type[select_id] = c_SETTING_TYPE_ID_STANDARD;

                    my_Set_Standard_Setting_Data((byte)(select_id + 1), app_setting_data.standard_select_idx[select_id]);
                }
            }
            catch
            {
            }
        }

        private void rbtn_custom_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                byte select_id = byte.Parse(((RadioButton)sender).Tag.ToString());
                if (((RadioButton)sender).Checked == true)
                {
                    app_setting_data.setting_type[select_id] = c_SETTING_TYPE_ID_CUSTOM;

                    my_Set_Standard_Setting_Data((byte)(select_id + 1), -1);

                    my_Set_Costom_Select_Picture(select_id+1, true);
                }
                else
                {
                    my_Set_Costom_Select_Picture(select_id+1, false);
                }
            }
            catch
            {
            }
        }

        private void cmbbx_standard_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int sel_idx = ((ComboBox)sender).SelectedIndex;
                byte tag_id = (byte)(byte.Parse(((ComboBox)sender).Tag.ToString()) + 1);
                my_Set_Standard_Setting_Data(tag_id, sel_idx);
            }
            catch
            {
            }
        }
        private void my_Set_Standard_Setting_Data(byte unit_no, int select_idx)
        {
            try
            {
                if (app_setting_data.setting_type[unit_no - 1] == c_SETTING_TYPE_ID_STANDARD)
                {
                    if (0 <= select_idx && select_idx < C_STANDARD_SETTING_NUM)
                    {
                        if (1 <= unit_no && unit_no <= c_NIXIE_MAX_UNIT_NUM)
                        {
                            for (int nixie_idx = 0; nixie_idx < c_NIXIE_TUBE_NUM; nixie_idx++)
                            {
                                app_setting_data.standard_setting_number[unit_no - 1, nixie_idx] = Standard_Setting_Number[select_idx, nixie_idx];
                                app_setting_data.standard_setting_control1[unit_no - 1, nixie_idx] = Standard_Setting_Control1[select_idx, nixie_idx];
                                app_setting_data.standard_setting_control2[unit_no - 1, nixie_idx] = Standard_Setting_Control2[select_idx, nixie_idx];
                            }
                            app_setting_data.standard_select_idx[unit_no - 1] = select_idx;
                        }
                    }
                }
                else if (app_setting_data.setting_type[unit_no - 1] == c_SETTING_TYPE_ID_CUSTOM)
                {
                    if (1 <= unit_no && unit_no <= c_NIXIE_MAX_UNIT_NUM)
                    {
                        for (int nixie_idx = 0; nixie_idx < c_NIXIE_TUBE_NUM; nixie_idx++)
                        {
                            app_setting_data.standard_setting_number[unit_no - 1, nixie_idx] = 0;
                            app_setting_data.standard_setting_control1[unit_no - 1, nixie_idx] = 0;
                            app_setting_data.standard_setting_control2[unit_no - 1, nixie_idx] = 0;
                        }

                        if (0 <= select_idx && select_idx < C_STANDARD_SETTING_NUM)
                        {
                            app_setting_data.standard_select_idx[unit_no - 1] = select_idx;
                        }
                    }
                }

            }
            catch
            {
            }
        }

        private void my_Read_App_Setting_Data(out ST_APP_SETTING_DATA p_app_data)
        {
            p_app_data = new ST_APP_SETTING_DATA();
            p_app_data.init(c_NIXIE_MAX_UNIT_NUM, c_NIXIE_TUBE_NUM);
            try
            {
                string tmp_setting_type = "";
                string tmp_number = "";
                string tmp_control1 = "";
                string tmp_control2 = "";
                string[] ary_setting_type = new string[0];
                string[] ary_number = new string[0];
                string[] ary_control1 = new string[0];
                string[] ary_control2 = new string[0];

                // LOOP TYPE
                p_app_data.loop_type = (byte)global::NixieKit.Properties.Settings.Default[c_KEY_LOOP_SETTING];

                // SETTING TYPE
                tmp_setting_type = (string)global::NixieKit.Properties.Settings.Default[c_KEY_SETTING_TYPE];
                if (tmp_setting_type != "")
                {
                    ary_setting_type = tmp_setting_type.Split(',');
                }
                // NUMBER
                tmp_number = (string)global::NixieKit.Properties.Settings.Default[c_KEY_NUMBER];
                if (tmp_number != "")
                {
                    ary_number = tmp_number.Split(',');
                }
                // SETTING TYPE
                tmp_control1 = (string)global::NixieKit.Properties.Settings.Default[c_KEY_CONTROL1];
                if (tmp_control1 != "")
                {
                    ary_control1 = tmp_control1.Split(',');
                }
                // SETTING TYPE
                tmp_control2 = (string)global::NixieKit.Properties.Settings.Default[c_KEY_CONTROL2];
                if (tmp_control2 != "")
                {
                    ary_control2 = tmp_control2.Split(',');
                }

                for (int unit_idx = 0; unit_idx < c_NIXIE_MAX_UNIT_NUM; unit_idx++)
                {
                    if (unit_idx < ary_setting_type.Length)
                    {
                        p_app_data.setting_type[unit_idx] = byte.Parse(ary_setting_type[unit_idx]);
                    }

                    for (int nixie_idx = 0; nixie_idx < c_NIXIE_TUBE_NUM; nixie_idx++)
                    {
                        if ((unit_idx * c_NIXIE_MAX_UNIT_NUM + nixie_idx) < ary_number.Length)
                        {
                            p_app_data.standard_setting_number[unit_idx, nixie_idx] = byte.Parse(ary_number[unit_idx * c_NIXIE_MAX_UNIT_NUM + nixie_idx]);
                        }
                        if ((unit_idx * c_NIXIE_MAX_UNIT_NUM + nixie_idx) < ary_control1.Length)
                        {
                            p_app_data.standard_setting_control1[unit_idx, nixie_idx] = byte.Parse(ary_control1[unit_idx * c_NIXIE_MAX_UNIT_NUM + nixie_idx]);
                        }
                        if ((unit_idx * c_NIXIE_MAX_UNIT_NUM + nixie_idx) < ary_control2.Length)
                        {
                            p_app_data.standard_setting_control2[unit_idx, nixie_idx] = byte.Parse(ary_control2[unit_idx * c_NIXIE_MAX_UNIT_NUM + nixie_idx]);
                        }
                    }
                }

                // Select idx�ݒ�
                for (int unit_idx = 0; unit_idx < c_NIXIE_MAX_UNIT_NUM; unit_idx++)
                {
                    byte set_idx = 0;
                    for (int select_idx = 0; select_idx < C_STANDARD_SETTING_NUM; select_idx++)
                    {
                        int match_count = 0;
                        for (int chk_nixie_idx = 0; chk_nixie_idx < c_NIXIE_TUBE_NUM; chk_nixie_idx++)
                        {
                            if (p_app_data.standard_setting_number[unit_idx, chk_nixie_idx] == Standard_Setting_Number[select_idx, chk_nixie_idx])
                            {
                                match_count++;
                            }
                            else
                            {
                                break;
                            }
                        }
                        for (int chk_nixie_idx = 0; chk_nixie_idx < c_NIXIE_TUBE_NUM; chk_nixie_idx++)
                        {
                            if (p_app_data.standard_setting_control1[unit_idx, chk_nixie_idx] == Standard_Setting_Control1[select_idx, chk_nixie_idx])
                            {
                                match_count++;
                            }
                            else
                            {
                                break;
                            }
                        }
                        for (int chk_nixie_idx = 0; chk_nixie_idx < c_NIXIE_TUBE_NUM; chk_nixie_idx++)
                        {
                            if (p_app_data.standard_setting_control2[unit_idx, chk_nixie_idx] == Standard_Setting_Control2[select_idx, chk_nixie_idx])
                            {
                                match_count++;
                            }
                            else
                            {
                                break;
                            }
                        }
                        if (match_count == (c_NIXIE_TUBE_NUM * 3))
                        {
                            set_idx = (byte)select_idx;
                            break;
                        }
                    }
                    p_app_data.standard_select_idx[unit_idx] = set_idx;
                }
            }
            catch
            {
            }
        }
        private void my_Save_App_Setting_Data(ST_APP_SETTING_DATA p_app_data)
        {
            try
            {
                string tmp_setting_type = "";
                string tmp_number = "";
                string tmp_control1 = "";
                string tmp_control2 = "";
                int count = 0;
                // LOOP TYPE
                global::NixieKit.Properties.Settings.Default[c_KEY_LOOP_SETTING] = p_app_data.loop_type;

                for (int unit_idx = 0; unit_idx < c_NIXIE_MAX_UNIT_NUM; unit_idx++)
                {
                    if (count > 0)
                    {
                        tmp_setting_type += ",";
                    }
                    tmp_setting_type += p_app_data.setting_type[unit_idx].ToString();

                    for (int nixie_idx = 0; nixie_idx < c_NIXIE_TUBE_NUM; nixie_idx++)
                    {
                        if (count > 0)
                        {
                            tmp_number += ",";
                            tmp_control1 += ",";
                            tmp_control2 += ",";
                        }
                        tmp_number += p_app_data.standard_setting_number[unit_idx, nixie_idx].ToString();
                        tmp_control1 += p_app_data.standard_setting_control1[unit_idx, nixie_idx].ToString();
                        tmp_control2 += p_app_data.standard_setting_control2[unit_idx, nixie_idx].ToString();
                        count++;
                    }
                }
                // SETTING TYPE
                global::NixieKit.Properties.Settings.Default[c_KEY_SETTING_TYPE] = tmp_setting_type;
                // NUMBER
                global::NixieKit.Properties.Settings.Default[c_KEY_NUMBER] = tmp_number;
                // SETTING TYPE
                global::NixieKit.Properties.Settings.Default[c_KEY_CONTROL1] = tmp_control1;
                // SETTING TYPE
                global::NixieKit.Properties.Settings.Default[c_KEY_CONTROL2] = tmp_control2;

                global::NixieKit.Properties.Settings.Default.Save();

            }
            catch
            {
            }
        }
        private void my_Set_Disp_App_Setting_Data(ST_APP_SETTING_DATA p_app_data)
        {
            try
            {
                int set_idx = 0;
                // LOOP TYPE
                if (p_app_data.loop_type < my_rbn_loop_type.Length)
                {
                    set_idx = p_app_data.loop_type;
                }
                my_rbn_loop_type[set_idx].Checked = true;

                // SETTING TYPE
                for (int unit_idx = 0; unit_idx < c_NIXIE_MAX_UNIT_NUM; unit_idx++)
                {
                    set_idx = 0;
                    if (p_app_data.setting_type[unit_idx] < my_chkbx_Setting_Type.GetLength(1))
                    {
                        set_idx = p_app_data.setting_type[unit_idx];
                    }
                    my_chkbx_Setting_Type[unit_idx, set_idx].Checked = true;

                    set_idx = 0;
                    if (p_app_data.standard_select_idx[unit_idx] < my_cmbbx_Standards[unit_idx].Items.Count)
                    {
                        set_idx = p_app_data.standard_select_idx[unit_idx];
                    }
                    my_cmbbx_Standards[unit_idx].SelectedIndex = set_idx;
                }


            }
            catch
            {
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                b_Blink_Interval_Set_flag = true;
            }
            catch
            {
            }
        }

        private void lbl_Set_Date_Click(object sender, EventArgs e)
        {
            bool error_flag = false;
            DateTime dt = DateTime.Now;
            try
            {
                try
                {
                    Time_Set_Num[0] = dt.Second;
                    Time_Set_Num[1] = dt.Minute;
                    Time_Set_Num[2] = dt.Hour;
                    Time_Set_Num[3] = (int)dt.DayOfWeek;
                    Time_Set_Num[4] = dt.Day;
                    Time_Set_Num[5] = dt.Month;
                    Time_Set_Num[6] = dt.Year % 100;    // �N�̉��Q��
                }
                catch
                {
                    error_flag = true;
                }
                if (error_flag == false)
                {
                    b_TimeSet_flag = true;
                }
            }
            catch
            {
            }
        }

        private void lbl_Set_Date_MouseDown(object sender, MouseEventArgs e)
        {
            try
            {
                if ((((System.Windows.Forms.Label)sender).ImageIndex % 3) == 1)
                {
                    ((System.Windows.Forms.Label)sender).ImageIndex++;
                }
            }
            catch
            {
            }
        }

        private void lbl_Set_Date_MouseUp(object sender, MouseEventArgs e)
        {
            try
            {
                if ((((System.Windows.Forms.Label)sender).ImageIndex % 3) == 2)
                {
                    ((System.Windows.Forms.Label)sender).ImageIndex--;
                }
            }
            catch
            {
            }
        }

        private void lbl_Set_Date_MouseEnter(object sender, EventArgs e)
        {
            try
            {
                if ((((System.Windows.Forms.Label)sender).ImageIndex % 3) == 0)
                {
                    ((System.Windows.Forms.Label)sender).ImageIndex++;
                }
            }
            catch
            {
            }
        }

        private void lbl_Set_Date_MouseLeave(object sender, EventArgs e)
        {
            try
            {
                if ((((System.Windows.Forms.Label)sender).ImageIndex % 3) == 1)
                {
                    ((System.Windows.Forms.Label)sender).ImageIndex--;
                }
            }
            catch
            {
            }
        }

        private void my_Set_Costom_Select_Picture(int p_unit_no, bool p_set_val)
        {
            try
            {
                if (1 <= p_unit_no && p_unit_no <= c_NIXIE_MAX_UNIT_NUM)
                {
                    my_picbx_Costom_Select[p_unit_no - 1].Visible = p_set_val;
                }
            }
            catch
            {
            }
        }

        private void dgv_DispSetData_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Delete)
                {
                    // Delete Key Down

                }
            }
            catch
            {
            }
        }

        private Rectangle dragBoxFromMouseDown;
        private int indexOfItemUnderMouseToDrag;
        private int indexOfItemUnderMouseToDrop;

        private void dgv_DispSetData_DragDrop(object sender, DragEventArgs e)
        {
            try
            {
                // The mouse locations are relative to the screen, so they must be
                // converted to client coordinates.
                Point clientPoint = dgv_DispSetData.PointToClient(new Point(e.X, e.Y));
                // Get the row index of the item the mouse is below.
                indexOfItemUnderMouseToDrop = dgv_DispSetData.HitTest(clientPoint.X, clientPoint.Y).RowIndex;
                // If the drag operation was a move then remove and insert the row.
                if (e.Effect == DragDropEffects.Move)
                {
                    if (e.Data.GetDataPresent(DataFormats.FileDrop))
                    {
                        //�h���b�v���ꂽ���ׂẴt�@�C�������擾����
                        string[] fileName = (string[])e.Data.GetData(DataFormats.FileDrop, false);
                        string file_ex = Path.GetExtension(fileName[0]);
                        file_ex = file_ex.ToLower();

                        // CSV�t�@�C���̏ꍇ
                        if (file_ex == ".csv" && fileName.Length == 1)
                        {
                            my_Import_File(fileName[0]);
                        }
                    }
                    else if (indexOfItemUnderMouseToDrop != -1)
                    {
                        if (dgv_DispSetData.SelectedRows.Count == 1 && indexOfItemUnderMouseToDrop < (dgv_DispSetData.Rows.Count-1))
                        {
                            DataGridViewRow rowArray = dgv_DispSetData.Rows[indexOfItemUnderMouseToDrag];
                            dgv_DispSetData.Rows.RemoveAt(indexOfItemUnderMouseToDrag);
                            for (int fi = 0; fi < (dgv_DispSetData.Rows.Count - 1); fi++ )
                            {
                                dgv_DispSetData.Rows[fi].Selected = false;
                            }
                            dgv_DispSetData.Rows.InsertRange(indexOfItemUnderMouseToDrop, rowArray);
                            dgv_DispSetData.CurrentCell = dgv_DispSetData.Rows[indexOfItemUnderMouseToDrop].Cells[0];
                            dgv_DispSetData.Rows[indexOfItemUnderMouseToDrop].Selected = true;
                        }
                    }
                }
            }
            catch
            {
            }
        }

        private void dgv_DispSetData_DragOver(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
        }

        private void dgv_DispSetData_MouseMove(object sender, MouseEventArgs e)
        {
            try
            {
                if ((e.Button & MouseButtons.Left) == MouseButtons.Left)
                {
                    // If the mouse moves outside the rectangle, start the drag.
                    if (dragBoxFromMouseDown != Rectangle.Empty &&
                    !dragBoxFromMouseDown.Contains(e.X, e.Y))
                    {
                        // Proceed with the drag and drop, passing in the list item.                   
                        DragDropEffects dropEffect = dgv_DispSetData.DoDragDrop(
                        dgv_DispSetData.Rows[indexOfItemUnderMouseToDrag],
                        DragDropEffects.Move);
                    }
                }
            }
            catch
            {
            }
        }

        private void dgv_DispSetData_MouseDown(object sender, MouseEventArgs e)
        {
            try
            {
                // Get the index of the item the mouse is below.
                indexOfItemUnderMouseToDrag = dgv_DispSetData.HitTest(e.X, e.Y).RowIndex;
                if (indexOfItemUnderMouseToDrag != -1)
                {
                    // Remember the point where the mouse down occurred. The DragSize indicates
                    // the size that the mouse can move before a drag event should be started.                
                    Size dragSize = SystemInformation.DragSize;

                    // Create a rectangle using the DragSize, with the mouse position being
                    // at the center of the rectangle.
                    dragBoxFromMouseDown = new Rectangle(new Point(e.X - (dragSize.Width / 2),
                                                                   e.Y - (dragSize.Height / 2)), dragSize);

                }
                else
                {
                    // Reset the rectangle if the mouse is not over an item in the ListBox.
                    dragBoxFromMouseDown = Rectangle.Empty;
                }
            }
            catch
            {
            }
        }

        //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------


    } //public partial class Form1 : Form
} //namespace NixieKit